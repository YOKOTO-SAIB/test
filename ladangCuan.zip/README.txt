==================================================
MONNEKO - MINING & ENTERTAINMENT PLATFORM
==================================================

🎯 KONSEP UTAMA:
Platform hiburan yang menghasilkan uang melalui:
1. Mining YFS (passive income)
2. Nonton anime dengan iklan
3. Main game online
4. Sistem referral 10%

TARGET: 10,000 user aktif dalam 1 bulan

==================================================
📦 FILE STRUCTURE:
==================================================

HTML FILES:
- index.html         → Landing page
- register.html      → Registrasi user
- login.html         → Login page
- dashboard.html     → Dashboard utama
- mining.html        → Mining YFS page
- anime.html         → List anime
- anime-player.html  → Player anime
- games.html         → List games
- game-play.html     → Play game
- withdrawal.html    → Tarik dana
- store.html         → Toko pulsa/produk
- profile.html       → Profile user
- inbox.html         → Pesan/notifikasi
- admin.html         → Admin panel

CSS FILES:
- style.css          → Style utama (Wibuku theme)
- admin.css          → Style admin panel

JAVASCRIPT FILES:
- main.js            → Core app logic
- mining.js          → Mining system
- anime.js           → Anime functions
- games.js           → Games logic
- admin.js           → Admin panel
- atlantik.js        → Atlantik H2H API integration

JSON FILES:
- config.json        → Configuration & API keys
- products.json      → Store products data

TXT FILES:
- README.txt         → This file
- API_DOCS.txt       → API documentation

==================================================
⛏️ MINING YFS SYSTEM:
==================================================

PAKET IMBALAN HARIAN (Daily Contract):
- Durasi: 7 jam
- Mining rate: 0.00000000000001 YFS/detik
- Claim sekali per hari
- Tidak bisa stack
- Auto stop setelah 7 jam

PAKET BERHADIAH (Reward Contract):
- Durasi: 24 jam per stack
- Reward per iklan: +1 stack
- Bisa stack unlimited
- Mining rate: 0.00000000000001 YFS/detik per stack
- Semakin banyak stack, semakin cepat mining

WITHDRAWAL YFS:
- Minimum: 0.0000001 YFS
- Ke: Dana, OVO, GoPay, LinkAja
- Proses otomatis via Atlantik H2H API
- Waktu: 1-24 jam

==================================================
📺 ANIME SYSTEM:
==================================================

API: Jikan API (MyAnimeList)
Endpoint: https://api.jikan.moe/v4

FITUR:
- List anime trending/popular/genre
- Search anime
- Detail anime dengan poster
- Player dengan iklan pre-roll
- Banner iklan saat nonton
- Reward: 500 poin per episode

FLOW NONTON:
1. User pilih anime
2. Pilih episode
3. Wajib nonton iklan 15-30 detik
4. Video anime mulai (dengan banner ads)
5. Selesai nonton → dapat 500 poin

==================================================
🎮 GAME SYSTEM:
==================================================

GAMES AVAILABLE:
1. Flappy Bird Clone
2. Puzzle Sliding
3. Tic Tac Toe
4. Memory Card Game
5. Snake Game

REWARD:
- Main game: 300 poin
- High score bonus: +200 poin
- Interstitial ads setiap 3 games

==================================================
💰 WITHDRAWAL SYSTEM:
==================================================

METODE:
- Dana
- OVO
- GoPay
- LinkAja

MINIMUM:
- Poin: 10,000 poin = Rp 5,000
- YFS: 0.0000001 YFS

CARA KERJA:
1. User request withdrawal
2. Input nomor HP/account
3. System validasi
4. Kirim ke Atlantik H2H API
5. Auto transfer ke user
6. Update status & notifikasi

ATLANTIK H2H API:
API Key: Yn27HTj06ypT9R3WOlh0nRG1OqUzpumJxvc6Wgr1ypLpv5EXeqUXArgPDUvtO3jWwPaXIqQuOJVpb2tvr1PS5VD65FijrNILPLUr
Base URL: https://atlantikh2h.com/gateway/index.php
Docs: https://documenter.getpostman.com/view/7313893/2s9YXpUyMf

==================================================
🏪 STORE SYSTEM:
==================================================

PRODUK AVAILABLE (via Atlantik H2H):
- Pulsa all operator
- Paket data
- Token listrik
- Voucher game
- E-wallet top-up

PAYMENT:
- Bayar dengan poin
- Konversi: 10,000 poin = Rp 5,000

FITUR:
- Category filter
- Search product
- Order history
- Auto delivery via API

==================================================
📨 INBOX SYSTEM:
==================================================

TIPE MESSAGE:
1. System notification
2. Withdrawal status
3. Mining update
4. Admin broadcast
5. Referral notification

FITUR:
- Unread counter
- Mark as read
- Delete message
- Filter by type

==================================================
👥 REFERRAL SYSTEM:
==================================================

KOMISI: 10% selamanya
CARA KERJA:
1. User dapat link referral unik
2. Share link ke teman
3. Teman register via link
4. User dapat 10% dari semua earning teman

BONUS:
- Signup bonus referee: 1000 poin
- Per referral aktif: komisi terus

==================================================
🔐 ADMIN PANEL:
==================================================

LOGIN:
Email: admin@monneko.com
Password: MonNeko2026!

FITUR ADMIN:
1. Dashboard Real-time
   - Total users
   - Online users
   - Total earnings
   - Revenue stats
   
2. User Management
   - Search user by email
   - Edit balance (poin & YFS)
   - Ban/unban user
   - Reset password
   - View user detail
   
3. Content Management
   - Add/edit products
   - Set reward rates
   - Manage games
   
4. Withdrawal Management
   - Approve/reject manual
   - View all withdrawals
   - Transaction history
   
5. Broadcast System
   - Send message to specific user
   - Send to all users
   - Schedule message
   
6. System Settings
   - Maintenance mode
   - Edit rewards
   - API configuration
   
7. Analytics
   - User growth chart
   - Revenue chart
   - Activity heatmap

==================================================
🔧 SETUP & INSTALLATION:
==================================================

1. DOWNLOAD SEMUA FILE
   
2. EDIT config.json:
   - Atlantik H2H merchant_code (dapatkan dari dashboard Atlantik)
   - Admin password (ganti default)
   
3. UPLOAD KE HOSTING:
   - Pastikan support HTTPS
   - Upload semua file ke public_html atau www
   
4. SET PERMISSIONS:
   - chmod 755 untuk folder
   - chmod 644 untuk files
   
5. TEST:
   - Buka https://yourdomain.com
   - Test register & login
   - Test mining system
   - Test withdrawal (gunakan sandbox mode dulu)

==================================================
🔌 API INTEGRATION:
==================================================

HILLTOPADS:
- Meta tag verification: sudah di index.html
- Popunder script: sudah di index.html
- Banner ads: implementasi manual di halaman anime/games

ATLANTIK H2H:
File: atlantik.js
Functions:
- checkBalance()
- processWithdrawal()
- buyProduct()
- checkTransactionStatus()

JIKAN API (Anime):
File: anime.js
Functions:
- fetchTrendingAnime()
- searchAnime()
- getAnimeDetails()
- getAnimeEpisodes()

==================================================
💡 MONETIZATION STRATEGY:
==================================================

INCOME SOURCES:
1. HilltopAds Revenue
   - Popunder: $2-5 CPM
   - Banner: $0.5-2 CPM
   - Video ads: $5-15 CPM
   
2. User Balance Reserve
   - 30-40% dari ad revenue untuk user payout
   - 60-70% profit margin
   
3. Store Commission
   - Markup 5-10% dari produk

ESTIMASI (10k users):
- Ads: 50 ads/user/day × 10k users × 30 days = 15M impressions
- Revenue: 15M × $2 CPM = $30,000/month
- User payout: ~$10,000/month
- NET PROFIT: ~$20,000/month + store commission

==================================================
🚀 MARKETING PLAN:
==================================================

PHASE 1 (Week 1-2): 0-1000 users
- Soft launch
- Beta testing
- Fix bugs
- Gather feedback

PHASE 2 (Week 3-4): 1000-3000 users
- Social media campaign
- Influencer partnerships
- Referral contest

PHASE 3 (Month 2): 3000-10000 users
- Paid ads (Facebook/Instagram)
- TikTok viral marketing
- Community building
- Events & giveaways

==================================================
🔒 SECURITY:
==================================================

IMPLEMENTED:
✅ Password hashing
✅ Session management
✅ Rate limiting
✅ Input validation
✅ XSS prevention
✅ CSRF protection
✅ SQL injection prevention (for future backend)

RECOMMENDATIONS:
- Use HTTPS (wajib)
- Enable Cloudflare
- Regular backup
- Monitor suspicious activities
- Update dependencies

==================================================
🐛 TROUBLESHOOTING:
==================================================

Q: Mining tidak jalan?
A: Clear localStorage, refresh page, claim ulang

Q: Anime tidak muncul?
A: Jikan API mungkin down, tunggu beberapa menit

Q: Withdrawal pending terus?
A: Cek Atlantik H2H balance merchant, atau approve manual di admin

Q: Admin tidak bisa login?
A: Cek config.json, pastikan email & password benar

Q: User tidak dapat poin?
A: Cek localStorage, pastikan function reward jalan

==================================================
📞 SUPPORT:
==================================================

Email: support@monneko.com
Documentation: Baca file ini & API_DOCS.txt
Issues: Catat di changelog

==================================================
✅ CHECKLIST BEFORE LAUNCH:
==================================================

[ ] Edit config.json (API keys, admin password)
[ ] Upload all files to hosting
[ ] Test HTTPS working
[ ] Test register & login
[ ] Test mining system
[ ] Test anime watching
[ ] Test games
[ ] Test withdrawal (sandbox mode first)
[ ] Test store purchases
[ ] Test admin panel
[ ] Setup Atlantik H2H merchant account
[ ] Get HilltopAds approval
[ ] Create social media accounts
[ ] Prepare marketing materials
[ ] Set analytics (Google Analytics optional)
[ ] Final testing all features
[ ] LAUNCH! 🚀

==================================================
📝 NOTES:
==================================================

- Website ini menggunakan localStorage untuk demo
- Untuk production, migrate ke backend (PHP/Node.js + MySQL)
- Mining timer real-time menggunakan setInterval
- Referral tracking via localStorage (upgrade ke database)
- Withdrawal auto via Atlantik H2H API
- Admin panel real-time stats (simulated, upgrade dengan WebSocket)

==================================================
🎉 GOOD LUCK!
==================================================

Target: 10,000 user aktif dalam 1 bulan
Revenue: $20,000+/month potential

MonNeko Team
2026
