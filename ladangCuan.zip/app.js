/**
 * MonNeko - Main Application JavaScript
 * Version: 1.0.0
 * All core functionality for mining, anime, games, withdrawal, store, and admin
 */

// ==================== CONFIGURATION ====================
let CONFIG = {};

// Load configuration
async function loadConfig() {
    try {
        const response = await fetch('config.json');
        CONFIG = await response.json();
        console.log('✅ Configuration loaded');
    } catch (error) {
        console.error('❌ Failed to load config:', error);
        CONFIG = getDefaultConfig();
    }
}

function getDefaultConfig() {
    return {
        site: { name: "MonNeko", version: "1.0.0" },
        api: {
            atlantik_h2h: {
                key: "Yn27HTj06ypT9R3WOlh0nRG1OqUzpumJxvc6Wgr1ypLpv5EXeqUXArgPDUvtO3jWwPaXIqQuOJVpb2tvr1PS5VD65FijrNILPLUr",
                base_url: "https://atlantikh2h.com/gateway/index.php"
            },
            anime: { jikan_base_url: "https://api.jikan.moe/v4" }
        },
        mining: {
            yfs_per_second: 0.00000000000001,
            daily_contract_hours: 7,
            reward_contract_hours: 24,
            min_withdrawal: 0.0000001
        },
        rewards: {
            signup_bonus: 1000,
            watch_anime: 500,
            play_game: 300,
            watch_ad: 100,
            referral_percentage: 0.1
        }
    };
}

// ==================== UTILITY FUNCTIONS ====================
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
}

function formatNumber(num) {
    return new Intl.NumberFormat('id-ID').format(num);
}

function formatCurrency(amount) {
    return `Rp ${formatNumber(amount)}`;
}

function formatYFS(amount) {
    return amount.toFixed(16);
}

// ==================== AUTH FUNCTIONS ====================
function register(email, password, fullname, referralCode = '') {
    const users = JSON.parse(localStorage.getItem('monneko_users') || '[]');
    
    if (users.find(u => u.email === email)) {
        showNotification('Email sudah terdaftar!', 'error');
        return false;
    }
    
    const user = {
        id: 'user_' + Date.now(),
        email: email,
        password: btoa(password),
        fullname: fullname,
        balance_points: CONFIG.rewards?.signup_bonus || 1000,
        balance_yfs: 0,
        mining: {
            daily_active: false,
            daily_end_time: null,
            reward_stacks: 0,
            reward_end_time: null
        },
        referral_code: 'REF' + Math.random().toString(36).substr(2, 8).toUpperCase(),
        referred_by: referralCode,
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString()
    };
    
    users.push(user);
    localStorage.setItem('monneko_users', JSON.stringify(users));
    localStorage.setItem('monneko_current_user', JSON.stringify(user));
    
    showNotification('Registrasi berhasil! Bonus 1000 poin', 'success');
    return true;
}

function login(email, password) {
    const users = JSON.parse(localStorage.getItem('monneko_users') || '[]');
    const user = users.find(u => u.email === email && u.password === btoa(password));
    
    if (!user) {
        showNotification('Email atau password salah!', 'error');
        return false;
    }
    
    user.last_login = new Date().toISOString();
    localStorage.setItem('monneko_current_user', JSON.stringify(user));
    updateUserInStorage(user);
    
    showNotification('Login berhasil!', 'success');
    return true;
}

function logout() {
    localStorage.removeItem('monneko_current_user');
    window.location.href = 'index.html';
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem('monneko_current_user') || 'null');
}

function updateUserInStorage(user) {
    const users = JSON.parse(localStorage.getItem('monneko_users') || '[]');
    const index = users.findIndex(u => u.id === user.id);
    if (index !== -1) {
        users[index] = user;
        localStorage.setItem('monneko_users', JSON.stringify(users));
        localStorage.setItem('monneko_current_user', JSON.stringify(user));
    }
}

// ==================== MINING FUNCTIONS ====================
function startDailyMining() {
    const user = getCurrentUser();
    if (!user) return;
    
    if (user.mining.daily_active) {
        showNotification('Mining harian sudah aktif!', 'error');
        return;
    }
    
    const endTime = Date.now() + (CONFIG.mining.daily_contract_hours * 3600000);
    user.mining.daily_active = true;
    user.mining.daily_end_time = endTime;
    updateUserInStorage(user);
    
    showNotification('Mining harian dimulai! Durasi 7 jam', 'success');
    startMiningTimer();
}

function addRewardStack() {
    const user = getCurrentUser();
    if (!user) return;
    
    const stackEndTime = Date.now() + (CONFIG.mining.reward_contract_hours * 3600000);
    user.mining.reward_stacks += 1;
    user.mining.reward_end_time = stackEndTime;
    user.balance_points += CONFIG.rewards.watch_ad;
    updateUserInStorage(user);
    
    showNotification(`Stack +1! Total: ${user.mining.reward_stacks} stacks. Bonus +${CONFIG.rewards.watch_ad} poin`, 'success');
}

function startMiningTimer() {
    setInterval(() => {
        const user = getCurrentUser();
        if (!user) return;
        
        let yfsEarned = 0;
        
        if (user.mining.daily_active && Date.now() < user.mining.daily_end_time) {
            yfsEarned += CONFIG.mining.yfs_per_second;
        } else if (user.mining.daily_active) {
            user.mining.daily_active = false;
            user.mining.daily_end_time = null;
            showNotification('Mining harian selesai!', 'success');
        }
        
        if (user.mining.reward_stacks > 0 && Date.now() < user.mining.reward_end_time) {
            yfsEarned += CONFIG.mining.yfs_per_second * user.mining.reward_stacks;
        } else if (user.mining.reward_stacks > 0) {
            user.mining.reward_stacks = 0;
            user.mining.reward_end_time = null;
            showNotification('Mining reward selesai!', 'success');
        }
        
        if (yfsEarned > 0) {
            user.balance_yfs += yfsEarned;
            updateUserInStorage(user);
            updateMiningDisplay();
        }
    }, 1000);
}

function updateMiningDisplay() {
    const user = getCurrentUser();
    if (!user) return;
    
    const yfsDisplay = document.getElementById('yfsBalance');
    if (yfsDisplay) {
        yfsDisplay.textContent = formatYFS(user.balance_yfs);
    }
    
    const dailyTimer = document.getElementById('dailyTimer');
    if (dailyTimer && user.mining.daily_active) {
        const remaining = user.mining.daily_end_time - Date.now();
        const hours = Math.floor(remaining / 3600000);
        const minutes = Math.floor((remaining % 3600000) / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);
        dailyTimer.textContent = `${hours}:${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`;
    }
    
    const stackDisplay = document.getElementById('stackCount');
    if (stackDisplay) {
        stackDisplay.textContent = user.mining.reward_stacks;
    }
}

// ==================== ANIME FUNCTIONS ====================
async function fetchAnime(page = 1) {
    try {
        const response = await fetch(`${CONFIG.api.anime.jikan_base_url}/top/anime?page=${page}&limit=20`);
        const data = await response.json();
        return data.data;
    } catch (error) {
        console.error('Error fetching anime:', error);
        return [];
    }
}

async function searchAnime(query) {
    try {
        const response = await fetch(`${CONFIG.api.anime.jikan_base_url}/anime?q=${encodeURIComponent(query)}&limit=20`);
        const data = await response.json();
        return data.data;
    } catch (error) {
        console.error('Error searching anime:', error);
        return [];
    }
}

function rewardAnimeWatch() {
    const user = getCurrentUser();
    if (!user) return;
    
    user.balance_points += CONFIG.rewards.watch_anime;
    updateUserInStorage(user);
    
    showNotification(`+${CONFIG.rewards.watch_anime} poin dari nonton anime!`, 'success');
}

// ==================== GAME FUNCTIONS ====================
function rewardGamePlay(score) {
    const user = getCurrentUser();
    if (!user) return;
    
    let reward = CONFIG.rewards.play_game;
    if (score > 50) reward += 200;
    if (score > 100) reward += 300;
    
    user.balance_points += reward;
    updateUserInStorage(user);
    
    showNotification(`Game selesai! +${reward} poin`, 'success');
}

// ==================== WITHDRAWAL FUNCTIONS ====================
async function processWithdrawal(amount, method, accountNumber, accountName) {
    const user = getCurrentUser();
    if (!user) return false;
    
    if (user.balance_points < amount * 2) {
        showNotification('Saldo tidak cukup!', 'error');
        return false;
    }
    
    try {
        const formData = new FormData();
        formData.append('apikey', CONFIG.api.atlantik_h2h.key);
        formData.append('action', 'transfer');
        formData.append('destination', accountNumber);
        formData.append('amount', Math.floor(amount / 2));
        formData.append('type', method);
        
        const response = await fetch(CONFIG.api.atlantik_h2h.base_url, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            user.balance_points -= amount;
            updateUserInStorage(user);
            
            const withdrawal = {
                id: 'WD_' + Date.now(),
                user_id: user.id,
                amount: amount,
                amount_rupiah: Math.floor(amount / 2),
                method: method,
                account_number: accountNumber,
                account_name: accountName,
                status: 'success',
                trx_id: result.trx_id,
                created_at: new Date().toISOString()
            };
            
            const withdrawals = JSON.parse(localStorage.getItem('monneko_withdrawals') || '[]');
            withdrawals.push(withdrawal);
            localStorage.setItem('monneko_withdrawals', JSON.stringify(withdrawals));
            
            addInboxMessage(user.id, 'Withdrawal Berhasil', `Withdrawal ${formatCurrency(Math.floor(amount/2))} ke ${method} berhasil diproses!`, 'withdrawal');
            
            showNotification('Withdrawal berhasil!', 'success');
            return true;
        } else {
            showNotification('Withdrawal gagal: ' + (result.message || 'Unknown error'), 'error');
            return false;
        }
    } catch (error) {
        console.error('Withdrawal error:', error);
        showNotification('Terjadi kesalahan saat withdrawal', 'error');
        return false;
    }
}

async function processYFSWithdrawal(amount, method, accountNumber, accountName) {
    const user = getCurrentUser();
    if (!user) return false;
    
    if (user.balance_yfs < amount) {
        showNotification('Saldo YFS tidak cukup!', 'error');
        return false;
    }
    
    user.balance_yfs -= amount;
    updateUserInStorage(user);
    
    const withdrawal = {
        id: 'YFS_' + Date.now(),
        user_id: user.id,
        amount_yfs: amount,
        method: method,
        account_number: accountNumber,
        account_name: accountName,
        status: 'processing',
        created_at: new Date().toISOString()
    };
    
    const withdrawals = JSON.parse(localStorage.getItem('monneko_yfs_withdrawals') || '[]');
    withdrawals.push(withdrawal);
    localStorage.setItem('monneko_yfs_withdrawals', JSON.stringify(withdrawals));
    
    addInboxMessage(user.id, 'YFS Withdrawal', `Withdrawal ${formatYFS(amount)} YFS sedang diproses`, 'withdrawal');
    
    showNotification('YFS Withdrawal request berhasil!', 'success');
    return true;
}

// ==================== STORE FUNCTIONS ====================
async function buyProduct(productCode, destination) {
    const user = getCurrentUser();
    if (!user) return false;
    
    const products = JSON.parse(localStorage.getItem('monneko_products') || '[]');
    const product = products.find(p => p.id === productCode);
    
    if (!product) {
        showNotification('Produk tidak ditemukan!', 'error');
        return false;
    }
    
    if (user.balance_points < product.price_points) {
        showNotification('Saldo tidak cukup!', 'error');
        return false;
    }
    
    try {
        const formData = new FormData();
        formData.append('apikey', CONFIG.api.atlantik_h2h.key);
        formData.append('action', 'order');
        formData.append('product_code', productCode);
        formData.append('destination', destination);
        
        const response = await fetch(CONFIG.api.atlantik_h2h.base_url, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            user.balance_points -= product.price_points;
            updateUserInStorage(user);
            
            const purchase = {
                id: 'ORDER_' + Date.now(),
                user_id: user.id,
                product: product.name,
                price: product.price_points,
                destination: destination,
                trx_id: result.trx_id,
                sn: result.sn || '',
                status: 'success',
                created_at: new Date().toISOString()
            };
            
            const purchases = JSON.parse(localStorage.getItem('monneko_purchases') || '[]');
            purchases.push(purchase);
            localStorage.setItem('monneko_purchases', JSON.stringify(purchases));
            
            addInboxMessage(user.id, 'Pembelian Berhasil', `Pembelian ${product.name} berhasil! ${result.sn ? 'SN: ' + result.sn : ''}`, 'store');
            
            showNotification('Pembelian berhasil!', 'success');
            return true;
        } else {
            showNotification('Pembelian gagal: ' + (result.message || 'Unknown error'), 'error');
            return false;
        }
    } catch (error) {
        console.error('Purchase error:', error);
        showNotification('Terjadi kesalahan saat pembelian', 'error');
        return false;
    }
}

// ==================== INBOX FUNCTIONS ====================
function addInboxMessage(userId, title, message, type = 'system') {
    const inbox = JSON.parse(localStorage.getItem('monneko_inbox') || '[]');
    inbox.push({
        id: 'MSG_' + Date.now(),
        user_id: userId,
        title: title,
        message: message,
        type: type,
        read: false,
        created_at: new Date().toISOString()
    });
    localStorage.setItem('monneko_inbox', JSON.stringify(inbox));
}

function getInboxMessages(userId) {
    const inbox = JSON.parse(localStorage.getItem('monneko_inbox') || '[]');
    return inbox.filter(msg => msg.user_id === userId || msg.user_id === 'all').sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

function markMessageAsRead(messageId) {
    const inbox = JSON.parse(localStorage.getItem('monneko_inbox') || '[]');
    const message = inbox.find(msg => msg.id === messageId);
    if (message) {
        message.read = true;
        localStorage.setItem('monneko_inbox', JSON.stringify(inbox));
    }
}

function getUnreadCount(userId) {
    const messages = getInboxMessages(userId);
    return messages.filter(msg => !msg.read).length;
}

// ==================== ADMIN FUNCTIONS ====================
function isAdmin() {
    const user = getCurrentUser();
    return user && user.email === CONFIG.admin?.email;
}

function getAllUsers() {
    return JSON.parse(localStorage.getItem('monneko_users') || '[]');
}

function updateUserBalance(userId, pointsDelta, yfsDelta) {
    const users = getAllUsers();
    const user = users.find(u => u.id === userId);
    if (user) {
        user.balance_points += pointsDelta;
        user.balance_yfs += yfsDelta;
        localStorage.setItem('monneko_users', JSON.stringify(users));
        showNotification('Saldo user berhasil diupdate!', 'success');
    }
}

function broadcastMessage(title, message) {
    addInboxMessage('all', title, message, 'admin');
    showNotification('Pesan broadcast berhasil dikirim!', 'success');
}

function getOnlineUsers() {
    const users = getAllUsers();
    const now = Date.now();
    return users.filter(u => {
        const lastLogin = new Date(u.last_login).getTime();
        return now - lastLogin < 300000;
    }).length;
}

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', async () => {
    await loadConfig();
    
    const user = getCurrentUser();
    if (user) {
        startMiningTimer();
        updateMiningDisplay();
    }
    
    console.log('✅ MonNeko App initialized');
});

// Export functions for use in HTML
window.MonNeko = {
    register,
    login,
    logout,
    getCurrentUser,
    startDailyMining,
    addRewardStack,
    fetchAnime,
    searchAnime,
    rewardAnimeWatch,
    rewardGamePlay,
    processWithdrawal,
    processYFSWithdrawal,
    buyProduct,
    getInboxMessages,
    markMessageAsRead,
    getUnreadCount,
    isAdmin,
    getAllUsers,
    updateUserBalance,
    broadcastMessage,
    getOnlineUsers,
    showNotification,
    formatNumber,
    formatCurrency,
    formatYFS
};
