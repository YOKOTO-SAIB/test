const express = require('express');
const session = require('express-session');
const bodyParser = require('express').json;
const fs = require('fs').promises;
const path = require('path');
const { Client, IntentsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder, Routes, REST } = require('discord.js');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const QRCode = require('qrcode');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Express
app.use(express.static('.'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: crypto.randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// Initialize SQLite Database
let db;
async function initDatabase() {
    db = await open({
        filename: 'store.db',
        driver: sqlite3.Database
    });

    // Create tables
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT,
            whatsapp TEXT,
            telegram TEXT,
            balance INTEGER DEFAULT 0,
            referral_code TEXT UNIQUE,
            referred_by TEXT,
            total_earned INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            is_admin BOOLEAN DEFAULT 0,
            is_banned BOOLEAN DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            price INTEGER NOT NULL,
            stock INTEGER DEFAULT -1,
            image_url TEXT,
            download_link TEXT,
            telegram_link TEXT,
            web_link TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1,
            views INTEGER DEFAULT 0,
            purchases INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            icon TEXT,
            description TEXT,
            position INTEGER DEFAULT 0,
            is_active BOOLEAN DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            payment_method TEXT,
            customer_name TEXT,
            customer_wa TEXT,
            customer_email TEXT,
            customer_telegram TEXT,
            order_data TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        );

        CREATE TABLE IF NOT EXISTS tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE NOT NULL,
            user_id INTEGER,
            product_id INTEGER,
            expires_at TIMESTAMP,
            is_used BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (product_id) REFERENCES products (id)
        );

        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referrer_id INTEGER NOT NULL,
            referred_id INTEGER NOT NULL,
            amount_earned INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (referrer_id) REFERENCES users (id),
            FOREIGN KEY (referred_id) REFERENCES users (id)
        );

        CREATE TABLE IF NOT EXISTS store_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_name TEXT DEFAULT 'Premium Store',
            store_description TEXT,
            store_logo TEXT,
            min_withdrawal INTEGER DEFAULT 100000,
            referral_bonus INTEGER DEFAULT 5,
            telegram_bot_username TEXT,
            admin_password TEXT,
            payment_methods TEXT,
            theme_settings TEXT,
            maintenance_mode BOOLEAN DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS user_activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            activity_type TEXT NOT NULL,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );

        CREATE TABLE IF NOT EXISTS money_making_methods (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            earnings_per_action INTEGER DEFAULT 0,
            requirements TEXT,
            link_template TEXT,
            is_active BOOLEAN DEFAULT 1,
            max_daily_actions INTEGER DEFAULT 10
        );
    `);

    // Insert default data
    const defaultCategories = [
        { name: 'APK', icon: '📱', description: 'Aplikasi Premium Mod & Tools', position: 1 },
        { name: 'Preset', icon: '🎨', description: 'Preset & Lagu Premium', position: 2 },
        { name: 'Script', icon: '💻', description: 'Script Bot & Tools', position: 3 },
        { name: 'Jasa', icon: '🔧', description: 'Layanan Profesional', position: 4 },
        { name: 'Free', icon: '🎁', description: 'Gratis dengan Token', position: 5 }
    ];

    for (const cat of defaultCategories) {
        await db.run(
            'INSERT OR IGNORE INTO categories (name, icon, description, position) VALUES (?, ?, ?, ?)',
            [cat.name, cat.icon, cat.description, cat.position]
        );
    }

    // Insert default products
    const defaultProducts = [
        // APK Category
        {
            category: 'APK',
            name: 'Nexarion RAT',
            description: 'Remote Access Tool premium dengan fitur lengkap: keylogger, camera access, file manager, remote shell, dan banyak fitur lainnya. Support Android 5.0+',
            price: 500000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/4A90E2/FFFFFF?text=Nexarion+RAT',
            download_link: 'https://your-download-link.com/nexarion.rar',
            telegram_link: 'https://t.me/yourstore'
        },
        {
            category: 'APK',
            name: 'Spyware Premium',
            description: 'Spyware dengan stealth mode, auto-hide icon, real-time tracking, call recording, message monitoring, location tracking',
            price: 350000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/E74C3C/FFFFFF?text=Spyware+Premium',
            download_link: 'https://your-download-link.com/spyware.apk'
        },
        {
            category: 'APK',
            name: 'Ransomware Builder',
            description: 'Create custom ransomware dengan encryption kuat, payment gateway, admin panel, dan auto-decrypt',
            price: 750000,
            stock: 10,
            image_url: 'https://via.placeholder.com/400x300/2ECC71/FFFFFF?text=Ransomware+Builder',
            telegram_link: 'https://t.me/yourstore'
        },
        {
            category: 'APK',
            name: 'AM Mod Premium',
            description: 'Auto Message Mod untuk WhatsApp dengan unlimited messages, anti-ban, schedule message, group sender',
            price: 250000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/F39C12/FFFFFF?text=AM+Mod+Premium',
            download_link: 'https://your-download-link.com/ammod.apk'
        },
        {
            category: 'APK',
            name: 'WA GB Pro',
            description: 'WhatsApp GB versi premium dengan semua fitur unlocked: theme custom, hide status, auto-reply, message scheduler',
            price: 150000,
            stock: 50,
            image_url: 'https://via.placeholder.com/400x300/9B59B6/FFFFFF?text=WA+GB+Pro',
            download_link: 'https://your-download-link.com/wagb.apk'
        },
        
        // Script Category
        {
            category: 'Script',
            name: 'Bot Telegram Full Source',
            description: 'Bot Telegram dengan fitur admin panel, payment system, user management, broadcast message, dan multi-language',
            price: 300000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/3498DB/FFFFFF?text=Bot+Telegram',
            telegram_link: 'https://t.me/yourstore'
        },
        {
            category: 'Script',
            name: 'Base Bot Telegram',
            description: 'Base code bot Telegram dengan struktur modern, easy to customize, database support, dan plugin system',
            price: 150000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/1ABC9C/FFFFFF?text=Base+Bot',
            download_link: 'https://your-download-link.com/basebot.zip'
        },
        {
            category: 'Script',
            name: 'Spam NGL Script',
            description: 'Script spam NGL dengan proxy support, multi-account, auto-captcha bypass, dan high success rate',
            price: 200000,
            stock: 25,
            image_url: 'https://via.placeholder.com/400x300/E74C3C/FFFFFF?text=Spam+NGL',
            telegram_link: 'https://t.me/yourstore'
        },
        {
            category: 'Script',
            name: 'Unbanned WhatsApp Tool',
            description: 'Tools untuk unbanned WhatsApp dengan berbagai metode, support all versions, easy to use',
            price: 175000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/2ECC71/FFFFFF?text=Unbanned+WA',
            download_link: 'https://your-download-link.com/unbanned.zip'
        },
        {
            category: 'Script',
            name: 'DDoS Attack Script',
            description: 'DDoS script dengan Layer 4 & 7 attack, proxy list, auto-scan vulnerable, bypass protection',
            price: 500000,
            stock: 15,
            image_url: 'https://via.placeholder.com/400x300/34495E/FFFFFF?text=DDoS+Script',
            telegram_link: 'https://t.me/yourstore'
        },
        {
            category: 'Script',
            name: 'Website Store System',
            description: 'Full source code website store seperti ini dengan admin panel, payment system, referral system',
            price: 750000,
            stock: -1,
            image_url: 'https://via.placeholder.com/400x300/9B59B6/FFFFFF?text=Website+Store',
            download_link: 'https://your-download-link.com/store-system.zip'
        }
    ];

    for (const product of defaultProducts) {
        await db.run(
            `INSERT OR IGNORE INTO products 
            (category, name, description, price, stock, image_url, download_link, telegram_link) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                product.category,
                product.name,
                product.description,
                product.price,
                product.stock,
                product.image_url,
                product.download_link,
                product.telegram_link
            ]
        );
    }

    // Insert money making methods
    const moneyMethods = [
        {
            name: 'Referral System',
            description: 'Dapatkan Rp 5 untuk setiap user yang mendaftar menggunakan link referral Anda',
            earnings_per_action: 5,
            requirements: 'Minimal withdrawal Rp 100.000',
            link_template: '/ref/{referral_code}',
            max_daily_actions: 1000
        },
        {
            name: 'Share & Earn',
            description: 'Bagikan produk dan dapatkan komisi 10% dari setiap pembelian melalui link Anda',
            earnings_per_action: 0, // percentage based
            requirements: 'Harus memiliki minimal 1 pembelian',
            link_template: '/share/{product_id}/{referral_code}',
            max_daily_actions: 50
        },
        {
            name: 'Watch Ads',
            description: 'Tonton iklan dan dapatkan Rp 1000 per iklan',
            earnings_per_action: 1000,
            requirements: 'Verifikasi email dan nomor WhatsApp',
            max_daily_actions: 10
        }
    ];

    for (const method of moneyMethods) {
        await db.run(
            `INSERT OR IGNORE INTO money_making_methods 
            (name, description, earnings_per_action, requirements, link_template, max_daily_actions) 
            VALUES (?, ?, ?, ?, ?, ?)`,
            [
                method.name,
                method.description,
                method.earnings_per_action,
                method.requirements,
                method.link_template,
                method.max_daily_actions
            ]
        );
    }

    // Insert default admin
    const adminPassword = await bcrypt.hash('admin123', 10);
    await db.run(
        `INSERT OR IGNORE INTO users 
        (email, password, name, is_admin, balance, referral_code) 
        VALUES (?, ?, ?, ?, ?, ?)`,
        ['admin@store.com', adminPassword, 'Administrator', 1, 1000000, 'ADMIN001']
    );

    // Insert store settings
    await db.run(
        `INSERT OR IGNORE INTO store_settings 
        (store_name, store_description, min_withdrawal, referral_bonus, telegram_bot_username) 
        VALUES (?, ?, ?, ?, ?)`,
        ['Premium Tools Store', 'Tempat beli tools & script premium terpercaya', 100000, 5, '@YourStoreBot']
    );
}

// Discord Bot Setup
const discordClient = new Client({
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent
    ]
});

const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const DISCORD_GUILD_ID = process.env.DISCORD_GUILD_ID;
const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID;

// Discord Commands
const commands = [
    new SlashCommandBuilder()
        .setName('addmoney')
        .setDescription('Tambahkan saldo ke user')
        .addStringOption(option =>
            option.setName('email')
                .setDescription('Email user')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Jumlah saldo')
                .setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('edituser')
        .setDescription('Edit data user')
        .addStringOption(option =>
            option.setName('email')
                .setDescription('Email user')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('field')
                .setDescription('Field yang diedit')
                .setRequired(true)
                .addChoices(
                    { name: 'Balance', value: 'balance' },
                    { name: 'Name', value: 'name' },
                    { name: 'WhatsApp', value: 'whatsapp' },
                    { name: 'Telegram', value: 'telegram' }
                ))
        .addStringOption(option =>
            option.setName('value')
                .setDescription('Nilai baru')
                .setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('addproduct')
        .setDescription('Tambah produk baru')
        .addStringOption(option =>
            option.setName('category')
                .setDescription('Kategori produk')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Nama produk')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Deskripsi produk')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('price')
                .setDescription('Harga produk')
                .setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('listusers')
        .setDescription('List semua user'),
    
    new SlashCommandBuilder()
        .setName('listproducts')
        .setDescription('List semua produk'),
    
    new SlashCommandBuilder()
        .setName('listorders')
        .setDescription('List semua order'),
    
    new SlashCommandBuilder()
        .setName('banuser')
        .setDescription('Ban user')
        .addStringOption(option =>
            option.setName('email')
                .setDescription('Email user')
                .setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('unbanuser')
        .setDescription('Unban user')
        .addStringOption(option =>
            option.setName('email')
                .setDescription('Email user')
                .setRequired(true)),
    
    new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Lihat statistik store'),
    
    new SlashCommandBuilder()
        .setName('broadcast')
        .setDescription('Broadcast message ke semua user')
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Pesan yang dikirim')
                .setRequired(true))
];

// Register commands
async function registerCommands() {
    try {
        const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);
        
        console.log('Registering slash commands...');
        
        await rest.put(
            Routes.applicationGuildCommands(DISCORD_CLIENT_ID, DISCORD_GUILD_ID),
            { body: commands }
        );
        
        console.log('Successfully registered slash commands!');
    } catch (error) {
        console.error('Error registering commands:', error);
    }
}

// Discord Bot Events
discordClient.once('ready', () => {
    console.log(`Discord Bot logged in as ${discordClient.user.tag}`);
    registerCommands();
});

discordClient.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName, options } = interaction;

    // Check if user is admin
    if (!interaction.member.permissions.has('ADMINISTRATOR')) {
        return interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini!', ephemeral: true });
    }

    try {
        switch (commandName) {
            case 'addmoney':
                const email = options.getString('email');
                const amount = options.getInteger('amount');
                
                const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
                if (!user) {
                    return interaction.reply({ content: '❌ User tidak ditemukan!', ephemeral: true });
                }
                
                await db.run('UPDATE users SET balance = balance + ? WHERE email = ?', [amount, email]);
                
                // Log activity
                await db.run(
                    'INSERT INTO user_activities (user_id, activity_type, details) VALUES (?, ?, ?)',
                    [user.id, 'admin_add_money', `Admin added ${amount} to balance`]
                );
                
                const embed = new EmbedBuilder()
                    .setTitle('💰 Saldo Ditambahkan')
                    .setColor(0x00FF00)
                    .addFields(
                        { name: 'User', value: user.email, inline: true },
                        { name: 'Jumlah', value: `Rp ${amount.toLocaleString()}`, inline: true },
                        { name: 'Saldo Baru', value: `Rp ${(user.balance + amount).toLocaleString()}`, inline: true }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [embed] });
                break;
                
            case 'edituser':
                const editEmail = options.getString('email');
                const field = options.getString('field');
                const value = options.getString('value');
                
                const editUser = await db.get('SELECT * FROM users WHERE email = ?', [editEmail]);
                if (!editUser) {
                    return interaction.reply({ content: '❌ User tidak ditemukan!', ephemeral: true });
                }
                
                let sqlField;
                switch (field) {
                    case 'balance':
                        sqlField = 'balance';
                        break;
                    case 'name':
                        sqlField = 'name';
                        break;
                    case 'whatsapp':
                        sqlField = 'whatsapp';
                        break;
                    case 'telegram':
                        sqlField = 'telegram';
                        break;
                    default:
                        return interaction.reply({ content: '❌ Field tidak valid!', ephemeral: true });
                }
                
                await db.run(`UPDATE users SET ${sqlField} = ? WHERE email = ?`, [value, editEmail]);
                
                const editEmbed = new EmbedBuilder()
                    .setTitle('👤 User Diupdate')
                    .setColor(0x3498DB)
                    .addFields(
                        { name: 'User', value: editEmail, inline: true },
                        { name: 'Field', value: field, inline: true },
                        { name: 'Nilai Baru', value: value, inline: true }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [editEmbed] });
                break;
                
            case 'addproduct':
                const category = options.getString('category');
                const name = options.getString('name');
                const description = options.getString('description');
                const price = options.getInteger('price');
                
                await db.run(
                    'INSERT INTO products (category, name, description, price) VALUES (?, ?, ?, ?)',
                    [category, name, description, price]
                );
                
                const productEmbed = new EmbedBuilder()
                    .setTitle('🆕 Produk Ditambahkan')
                    .setColor(0x9B59B6)
                    .addFields(
                        { name: 'Nama', value: name, inline: true },
                        { name: 'Kategori', value: category, inline: true },
                        { name: 'Harga', value: `Rp ${price.toLocaleString()}`, inline: true },
                        { name: 'Deskripsi', value: description.substring(0, 100) + '...' }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [productEmbed] });
                break;
                
            case 'listusers':
                const users = await db.all('SELECT email, name, balance, is_admin, created_at FROM users ORDER BY created_at DESC LIMIT 10');
                
                if (users.length === 0) {
                    return interaction.reply({ content: '📭 Tidak ada user terdaftar!', ephemeral: true });
                }
                
                const userListEmbed = new EmbedBuilder()
                    .setTitle('👥 List User (10 Terbaru)')
                    .setColor(0xF1C40F)
                    .setTimestamp();
                
                users.forEach((user, index) => {
                    userListEmbed.addFields({
                        name: `${index + 1}. ${user.email}`,
                        value: `Nama: ${user.name || '-'}\nSaldo: Rp ${user.balance.toLocaleString()}\nAdmin: ${user.is_admin ? '✅' : '❌'}\nDaftar: ${new Date(user.created_at).toLocaleDateString()}`,
                        inline: false
                    });
                });
                
                await interaction.reply({ embeds: [userListEmbed] });
                break;
                
            case 'stats':
                const totalUsers = await db.get('SELECT COUNT(*) as count FROM users');
                const totalProducts = await db.get('SELECT COUNT(*) as count FROM products');
                const totalOrders = await db.get('SELECT COUNT(*) as count FROM orders');
                const totalRevenue = await db.get('SELECT SUM(amount) as total FROM orders WHERE status = "completed"');
                const activeUsers = await db.get('SELECT COUNT(DISTINCT user_id) as count FROM user_activities WHERE created_at > datetime("now", "-7 days")');
                
                const statsEmbed = new EmbedBuilder()
                    .setTitle('📊 Store Statistics')
                    .setColor(0x2ECC71)
                    .addFields(
                        { name: 'Total Users', value: totalUsers.count.toString(), inline: true },
                        { name: 'Active Users (7d)', value: activeUsers.count.toString(), inline: true },
                        { name: 'Total Products', value: totalProducts.count.toString(), inline: true },
                        { name: 'Total Orders', value: totalOrders.count.toString(), inline: true },
                        { name: 'Total Revenue', value: `Rp ${(totalRevenue.total || 0).toLocaleString()}`, inline: true }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [statsEmbed] });
                break;
                
            case 'broadcast':
                const message = options.getString('message');
                
                // Get all users with notification enabled
                const allUsers = await db.all('SELECT email FROM users');
                
                const broadcastEmbed = new EmbedBuilder()
                    .setTitle('📢 Broadcast Message')
                    .setDescription(message)
                    .setColor(0xE74C3C)
                    .setTimestamp();
                
                await interaction.reply({ 
                    content: `✅ Broadcast dikirim ke ${allUsers.length} users!`,
                    embeds: [broadcastEmbed],
                    ephemeral: true 
                });
                break;
        }
    } catch (error) {
        console.error('Error handling command:', error);
        await interaction.reply({ content: '❌ Terjadi error saat memproses command!', ephemeral: true });
    }
});

// Express Routes - Authentication
app.post('/api/register', async (req, res) => {
    try {
        const { email, password, name, referral_code } = req.body;
        
        if (!email || !password) {
            return res.json({ success: false, message: 'Email dan password harus diisi!' });
        }
        
        // Check if user exists
        const existingUser = await db.get('SELECT * FROM users WHERE email = ?', [email]);
        if (existingUser) {
            return res.json({ success: false, message: 'Email sudah terdaftar!' });
        }
        
        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Generate referral code
        const userReferralCode = crypto.randomBytes(4).toString('hex').toUpperCase();
        
        // Insert user
        await db.run(
            `INSERT INTO users (email, password, name, referral_code) 
            VALUES (?, ?, ?, ?)`,
            [email, hashedPassword, name, userReferralCode]
        );
        
        // Handle referral
        if (referral_code) {
            const referrer = await db.get('SELECT * FROM users WHERE referral_code = ?', [referral_code]);
            if (referrer) {
                const newUser = await db.get('SELECT * FROM users WHERE email = ?', [email]);
                
                await db.run(
                    'INSERT INTO referrals (referrer_id, referred_id, amount_earned) VALUES (?, ?, ?)',
                    [referrer.id, newUser.id, 5]
                );
                
                await db.run(
                    'UPDATE users SET balance = balance + 5, total_earned = total_earned + 5 WHERE id = ?',
                    [referrer.id]
                );
            }
        }
        
        // Set session
        req.session.user = { email, name };
        
        res.json({ 
            success: true, 
            message: 'Registrasi berhasil!',
            referral_code: userReferralCode
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        res.json({ success: false, message: 'Terjadi error saat registrasi!' });
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
        if (!user) {
            return res.json({ success: false, message: 'Email atau password salah!' });
        }
        
        if (user.is_banned) {
            return res.json({ success: false, message: 'Akun Anda dibanned!' });
        }
        
        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.json({ success: false, message: 'Email atau password salah!' });
        }
        
        // Update last login
        await db.run('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', [user.id]);
        
        // Log activity
        await db.run(
            'INSERT INTO user_activities (user_id, activity_type, ip_address, user_agent) VALUES (?, ?, ?, ?)',
            [user.id, 'login', req.ip, req.headers['user-agent']]
        );
        
        req.session.user = {
            id: user.id,
            email: user.email,
            name: user.name,
            is_admin: user.is_admin,
            balance: user.balance,
            referral_code: user.referral_code
        };
        
        res.json({ 
            success: true, 
            message: 'Login berhasil!',
            user: req.session.user
        });
        
    } catch (error) {
        console.error('Login error:', error);
        res.json({ success: false, message: 'Terjadi error saat login!' });
    }
});

app.get('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true, message: 'Logout berhasil!' });
});

// Express Routes - Products
app.get('/api/products', async (req, res) => {
    try {
        const { category } = req.query;
        
        let sql = 'SELECT * FROM products WHERE is_active = 1';
        let params = [];
        
        if (category && category !== 'all') {
            sql += ' AND category = ?';
            params.push(category);
        }
        
        sql += ' ORDER BY created_at DESC';
        
        const products = await db.all(sql, params);
        res.json({ success: true, products });
        
    } catch (error) {
        console.error('Get products error:', error);
        res.json({ success: false, message: 'Error mengambil data produk!' });
    }
});

app.get('/api/products/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const product = await db.get('SELECT * FROM products WHERE id = ?', [id]);
        if (!product) {
            return res.json({ success: false, message: 'Produk tidak ditemukan!' });
        }
        
        // Increment views
        await db.run('UPDATE products SET views = views + 1 WHERE id = ?', [id]);
        
        res.json({ success: true, product });
        
    } catch (error) {
        console.error('Get product error:', error);
        res.json({ success: false, message: 'Error mengambil data produk!' });
    }
});

app.get('/api/categories', async (req, res) => {
    try {
        const categories = await db.all('SELECT * FROM categories WHERE is_active = 1 ORDER BY position');
        res.json({ success: true, categories });
    } catch (error) {
        console.error('Get categories error:', error);
        res.json({ success: false, message: 'Error mengambil kategori!' });
    }
});

// Express Routes - Orders
app.post('/api/order', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Silakan login terlebih dahulu!' });
        }
        
        const { product_id, customer_name, customer_wa, customer_email, customer_telegram, payment_method } = req.body;
        
        // Get user and product
        const user = await db.get('SELECT * FROM users WHERE email = ?', [req.session.user.email]);
        const product = await db.get('SELECT * FROM products WHERE id = ?', [product_id]);
        
        if (!user || !product) {
            return res.json({ success: false, message: 'Data tidak valid!' });
        }
        
        // Check stock
        if (product.stock !== -1 && product.stock <= 0) {
            return res.json({ success: false, message: 'Stok habis!' });
        }
        
        // Check balance if paying with web balance
        if (payment_method === 'web_balance') {
            if (user.balance < product.price) {
                return res.json({ 
                    success: false, 
                    message: 'Saldo tidak mencukupi!',
                    needed: product.price - user.balance
                });
            }
        }
        
        // Create order
        const orderData = {
            customer_name,
            customer_wa,
            customer_email,
            customer_telegram,
            product_name: product.name,
            product_price: product.price,
            order_date: new Date().toISOString()
        };
        
        await db.run(
            `INSERT INTO orders 
            (user_id, product_id, amount, status, payment_method, 
             customer_name, customer_wa, customer_email, customer_telegram, order_data) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                user.id,
                product.id,
                product.price,
                'pending',
                payment_method,
                customer_name,
                customer_wa,
                customer_email,
                customer_telegram,
                JSON.stringify(orderData)
            ]
        );
        
        // If paying with balance, deduct immediately
        if (payment_method === 'web_balance') {
            await db.run('UPDATE users SET balance = balance - ? WHERE id = ?', [product.price, user.id]);
            await db.run('UPDATE orders SET status = "completed" WHERE user_id = ? ORDER BY id DESC LIMIT 1', [user.id]);
            
            // Update product stock
            if (product.stock !== -1) {
                await db.run('UPDATE products SET stock = stock - 1, purchases = purchases + 1 WHERE id = ?', [product.id]);
            }
            
            // Generate token for download if applicable
            if (product.download_link) {
                const token = crypto.randomBytes(32).toString('hex');
                await db.run(
                    'INSERT INTO tokens (token, user_id, product_id, expires_at) VALUES (?, ?, ?, datetime("now", "+7 days"))',
                    [token, user.id, product.id]
                );
            }
        }
        
        // Log activity
        await db.run(
            'INSERT INTO user_activities (user_id, activity_type, details) VALUES (?, ?, ?)',
            [user.id, 'purchase', `Purchased ${product.name} for Rp ${product.price}`]
        );
        
        res.json({ 
            success: true, 
            message: payment_method === 'web_balance' ? 'Pembelian berhasil!' : 'Order berhasil dibuat!',
            payment_method,
            needs_payment: payment_method !== 'web_balance'
        });
        
    } catch (error) {
        console.error('Order error:', error);
        res.json({ success: false, message: 'Error membuat order!' });
    }
});

// Express Routes - User
app.get('/api/user/profile', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Not authenticated' });
        }
        
        const user = await db.get(
            `SELECT u.*, 
             COUNT(DISTINCT r.referred_id) as total_referrals,
             SUM(r.amount_earned) as total_referral_earnings
             FROM users u
             LEFT JOIN referrals r ON u.id = r.referrer_id
             WHERE u.email = ?
             GROUP BY u.id`,
            [req.session.user.email]
        );
        
        if (!user) {
            return res.json({ success: false, message: 'User not found' });
        }
        
        // Get user orders
        const orders = await db.all(
            `SELECT o.*, p.name as product_name, p.image_url 
             FROM orders o
             JOIN products p ON o.product_id = p.id
             WHERE o.user_id = ?
             ORDER BY o.created_at DESC
             LIMIT 10`,
            [user.id]
        );
        
        // Get referral stats
        const referrals = await db.all(
            `SELECT r.*, u.email as referred_email, u.created_at as referred_date
             FROM referrals r
             JOIN users u ON r.referred_id = u.id
             WHERE r.referrer_id = ?
             ORDER BY r.created_at DESC`,
            [user.id]
        );
        
        res.json({ 
            success: true, 
            user: {
                ...user,
                password: undefined
            },
            orders,
            referrals
        });
        
    } catch (error) {
        console.error('Get profile error:', error);
        res.json({ success: false, message: 'Error mengambil data profil!' });
    }
});

app.post('/api/user/update', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Not authenticated' });
        }
        
        const { name, whatsapp, telegram } = req.body;
        
        await db.run(
            'UPDATE users SET name = ?, whatsapp = ?, telegram = ? WHERE email = ?',
            [name, whatsapp, telegram, req.session.user.email]
        );
        
        // Update session
        req.session.user.name = name;
        
        res.json({ success: true, message: 'Profil berhasil diupdate!' });
        
    } catch (error) {
        console.error('Update profile error:', error);
        res.json({ success: false, message: 'Error mengupdate profil!' });
    }
});

app.post('/api/user/withdraw', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Not authenticated' });
        }
        
        const { amount, method, account_number } = req.body;
        
        const user = await db.get('SELECT * FROM users WHERE email = ?', [req.session.user.email]);
        
        // Get min withdrawal from settings
        const settings = await db.get('SELECT min_withdrawal FROM store_settings LIMIT 1');
        const minWithdrawal = settings?.min_withdrawal || 100000;
        
        if (amount < minWithdrawal) {
            return res.json({ 
                success: false, 
                message: `Minimal withdrawal Rp ${minWithdrawal.toLocaleString()}!` 
            });
        }
        
        if (user.balance < amount) {
            return res.json({ success: false, message: 'Saldo tidak mencukupi!' });
        }
        
        // Create withdrawal record
        await db.run(
            'INSERT INTO orders (user_id, amount, status, payment_method, order_data) VALUES (?, ?, ?, ?, ?)',
            [
                user.id,
                amount,
                'withdrawal_pending',
                method,
                JSON.stringify({
                    type: 'withdrawal',
                    account_number,
                    request_date: new Date().toISOString()
                })
            ]
        );
        
        // Deduct balance
        await db.run('UPDATE users SET balance = balance - ? WHERE id = ?', [amount, user.id]);
        
        // Log activity
        await db.run(
            'INSERT INTO user_activities (user_id, activity_type, details) VALUES (?, ?, ?)',
            [user.id, 'withdrawal', `Withdrawal request Rp ${amount} via ${method}`]
        );
        
        res.json({ 
            success: true, 
            message: 'Permintaan withdrawal berhasil dikirim! Silakan tunggu konfirmasi admin.' 
        });
        
    } catch (error) {
        console.error('Withdrawal error:', error);
        res.json({ success: false, message: 'Error mengajukan withdrawal!' });
    }
});

// Express Routes - Money Making
app.get('/api/money/methods', async (req, res) => {
    try {
        const methods = await db.all('SELECT * FROM money_making_methods WHERE is_active = 1');
        res.json({ success: true, methods });
    } catch (error) {
        console.error('Get money methods error:', error);
        res.json({ success: false, message: 'Error mengambil metode penghasilan!' });
    }
});

app.post('/api/money/complete-task', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Not authenticated' });
        }
        
        const { method_id } = req.body;
        
        const user = await db.get('SELECT * FROM users WHERE email = ?', [req.session.user.email]);
        const method = await db.get('SELECT * FROM money_making_methods WHERE id = ?', [method_id]);
        
        if (!method) {
            return res.json({ success: false, message: 'Metode tidak ditemukan!' });
        }
        
        // Check daily limit
        const today = new Date().toISOString().split('T')[0];
        const todayTasks = await db.get(
            `SELECT COUNT(*) as count FROM user_activities 
             WHERE user_id = ? AND activity_type = ? AND DATE(created_at) = ?`,
            [user.id, `earn_${method_id}`, today]
        );
        
        if (todayTasks.count >= method.max_daily_actions) {
            return res.json({ success: false, message: 'Limit harian sudah tercapai!' });
        }
        
        // Add earnings
        await db.run('UPDATE users SET balance = balance + ?, total_earned = total_earned + ? WHERE id = ?', 
            [method.earnings_per_action, method.earnings_per_action, user.id]);
        
        // Log activity
        await db.run(
            'INSERT INTO user_activities (user_id, activity_type, details) VALUES (?, ?, ?)',
            [user.id, `earn_${method_id}`, `Earned Rp ${method.earnings_per_action} from ${method.name}`]
        );
        
        // Update user session
        req.session.user.balance += method.earnings_per_action;
        
        res.json({ 
            success: true, 
            message: `Berhasil mendapatkan Rp ${method.earnings_per_action}!`,
            new_balance: req.session.user.balance
        });
        
    } catch (error) {
        console.error('Complete task error:', error);
        res.json({ success: false, message: 'Error menyelesaikan task!' });
    }
});

// Express Routes - Free Tokens
app.get('/api/tokens/generate', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.json({ success: false, message: 'Not authenticated' });
        }
        
        const user = await db.get('SELECT * FROM users WHERE email = ?', [req.session.user.email]);
        
        // Generate token for free products
        const token = crypto.randomBytes(32).toString('hex');
        
        await db.run(
            'INSERT INTO tokens (token, user_id, expires_at) VALUES (?, ?, datetime("now", "+1 day"))',
            [token, user.id]
        );
        
        res.json({ 
            success: true, 
            message: 'Token berhasil dibuat!',
            token 
        });
        
    } catch (error) {
        console.error('Generate token error:', error);
        res.json({ success: false, message: 'Error membuat token!' });
    }
});

app.post('/api/tokens/redeem', async (req, res) => {
    try {
        const { token, product_id } = req.body;
        
        const tokenData = await db.get(
            'SELECT * FROM tokens WHERE token = ? AND is_used = 0 AND expires_at > CURRENT_TIMESTAMP',
            [token]
        );
        
        if (!tokenData) {
            return res.json({ success: false, message: 'Token tidak valid atau sudah kadaluarsa!' });
        }
        
        const product = await db.get('SELECT * FROM products WHERE id = ?', [product_id]);
        
        if (!product) {
            return res.json({ success: false, message: 'Produk tidak ditemukan!' });
        }
        
        // Mark token as used
        await db.run(
            'UPDATE tokens SET is_used = 1, product_id = ? WHERE id = ?',
            [product_id, tokenData.id]
        );
        
        res.json({ 
            success: true, 
            message: 'Token berhasil diredeem!',
            download_link: product.download_link 
        });
        
    } catch (error) {
        console.error('Redeem token error:', error);
        res.json({ success: false, message: 'Error menggunakan token!' });
    }
});

// Express Routes - Admin
app.get('/api/admin/dashboard', async (req, res) => {
    try {
        if (!req.session.user?.is_admin) {
            return res.json({ success: false, message: 'Access denied!' });
        }
        
        const stats = {
            totalUsers: await db.get('SELECT COUNT(*) as count FROM users'),
            totalProducts: await db.get('SELECT COUNT(*) as count FROM products'),
            totalOrders: await db.get('SELECT COUNT(*) as count FROM orders'),
            totalRevenue: await db.get('SELECT SUM(amount) as total FROM orders WHERE status = "completed"'),
            pendingOrders: await db.get('SELECT COUNT(*) as count FROM orders WHERE status = "pending"'),
            todayRevenue: await db.get('SELECT SUM(amount) as total FROM orders WHERE status = "completed" AND DATE(created_at) = DATE("now")'),
            recentUsers: await db.all('SELECT * FROM users ORDER BY created_at DESC LIMIT 10'),
            recentOrders: await db.all(
                `SELECT o.*, u.email, p.name as product_name 
                 FROM orders o 
                 JOIN users u ON o.user_id = u.id 
                 JOIN products p ON o.product_id = p.id 
                 ORDER BY o.created_at DESC LIMIT 10`
            )
        };
        
        res.json({ success: true, stats });
        
    } catch (error) {
        console.error('Admin dashboard error:', error);
        res.json({ success: false, message: 'Error mengambil data dashboard!' });
    }
});

app.post('/api/admin/update-product', async (req, res) => {
    try {
        if (!req.session.user?.is_admin) {
            return res.json({ success: false, message: 'Access denied!' });
        }
        
        const { id, field, value } = req.body;
        
        await db.run(`UPDATE products SET ${field} = ? WHERE id = ?`, [value, id]);
        
        res.json({ success: true, message: 'Produk berhasil diupdate!' });
        
    } catch (error) {
        console.error('Update product error:', error);
        res.json({ success: false, message: 'Error mengupdate produk!' });
    }
});

app.post('/api/admin/add-product', async (req, res) => {
    try {
        if (!req.session.user?.is_admin) {
            return res.json({ success: false, message: 'Access denied!' });
        }
        
        const { category, name, description, price, stock, image_url, download_link, telegram_link } = req.body;
        
        await db.run(
            `INSERT INTO products (category, name, description, price, stock, image_url, download_link, telegram_link) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [category, name, description, price, stock, image_url, download_link, telegram_link]
        );
        
        res.json({ success: true, message: 'Produk berhasil ditambahkan!' });
        
    } catch (error) {
        console.error('Add product error:', error);
        res.json({ success: false, message: 'Error menambahkan produk!' });
    }
});

// Express Routes - Store Settings
app.get('/api/store/settings', async (req, res) => {
    try {
        const settings = await db.get('SELECT * FROM store_settings LIMIT 1');
        res.json({ success: true, settings });
    } catch (error) {
        console.error('Get settings error:', error);
        res.json({ success: false, message: 'Error mengambil pengaturan!' });
    }
});

app.post('/api/store/update-settings', async (req, res) => {
    try {
        if (!req.session.user?.is_admin) {
            return res.json({ success: false, message: 'Access denied!' });
        }
        
        const { store_name, store_description, min_withdrawal, referral_bonus, telegram_bot_username } = req.body;
        
        await db.run(
            `UPDATE store_settings SET 
             store_name = ?, store_description = ?, min_withdrawal = ?, 
             referral_bonus = ?, telegram_bot_username = ? 
             WHERE id = 1`,
            [store_name, store_description, min_withdrawal, referral_bonus, telegram_bot_username]
        );
        
        res.json({ success: true, message: 'Pengaturan berhasil diupdate!' });
        
    } catch (error) {
        console.error('Update settings error:', error);
        res.json({ success: false, message: 'Error mengupdate pengaturan!' });
    }
});

// Referral System
app.get('/ref/:code', async (req, res) => {
    try {
        const { code } = req.params;
        
        const referrer = await db.get('SELECT * FROM users WHERE referral_code = ?', [code]);
        if (referrer) {
            // Store referral code in session
            req.session.referral_code = code;
            
            // Redirect to home
            res.redirect('/');
        } else {
            res.redirect('/');
        }
    } catch (error) {
        console.error('Referral error:', error);
        res.redirect('/');
    }
});

// Serve admin page
app.get('/admin', (req, res) => {
    if (!req.session.user?.is_admin) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Serve main page
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Start Server
async function startServer() {
    try {
        await initDatabase();
        console.log('Database initialized successfully!');
        
        // Start Discord Bot if token exists
        if (DISCORD_TOKEN) {
            await discordClient.login(DISCORD_TOKEN);
            console.log('Discord Bot connected successfully!');
        } else {
            console.log('Discord Bot token not provided, skipping...');
        }
        
        // Start Express Server
        app.listen(PORT, () => {
            console.log(`Server running on http://localhost:${PORT}`);
            console.log(`Admin panel: http://localhost:${PORT}/admin`);
            console.log(`Default admin: admin@store.com / admin123`);
        });
        
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
}

startServer();

// Error handling
process.on('unhandledRejection', (error) => {
    console.error('Unhandled promise rejection:', error);
});

process.on('uncaughtException', (error) => {
    console.error('Uncaught exception:', error);
    process.exit(1);
});