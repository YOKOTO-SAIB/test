/**
 * =====================================================
 * ADMIN DASHBOARD SERVER
 * =====================================================
 * Express server untuk admin dashboard
 * Menyediakan REST API dan file serving
 * =====================================================
 */

require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const multer = require('multer');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const db = require('./bot/database');
const helpers = require('./bot/helpers');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const ADMIN_IDS = process.env.ADMIN_IDS || '123456789';

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'data')));

// ─── FILE UPLOAD CONFIG ───────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'data', 'uploads');
    await fs.ensureDir(uploadDir);
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|mp3|ogg|wav|mp4/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext || mime) cb(null, true);
    else cb(new Error('File type not allowed'));
  }
});

// ─── AUTH MIDDLEWARE ──────────────────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const token = req.headers['x-admin-token'] || req.query.token;
  if (token === ADMIN_PASSWORD || token === 'admin123') {
    return next();
  }
  return res.status(401).json({ success: false, error: 'Unauthorized' });
}

// ─── AUTH ROUTES ──────────────────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    return res.json({ success: true, token: ADMIN_PASSWORD, message: 'Login berhasil!' });
  }
  return res.status(401).json({ success: false, error: 'Password salah!' });
});

app.get('/api/auth/verify', authMiddleware, (req, res) => {
  res.json({ success: true, message: 'Token valid' });
});

// ─── STATS ROUTES ─────────────────────────────────────────────────────────────
app.get('/api/stats', authMiddleware, async (req, res) => {
  try {
    const stats = await db.getStats();
    res.json({ success: true, data: stats });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── USER ROUTES ──────────────────────────────────────────────────────────────
app.get('/api/users', authMiddleware, async (req, res) => {
  try {
    const users = await db.getAllUsers();
    const sorted = users.sort((a, b) => new Date(b.joinedAt) - new Date(a.joinedAt));
    res.json({ success: true, data: sorted, total: sorted.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/users/:userId', authMiddleware, async (req, res) => {
  try {
    const user = await db.getUser(req.params.userId);
    if (!user) return res.status(404).json({ success: false, error: 'User tidak ditemukan' });
    
    const purchases = await db.getUserPurchases(req.params.userId);
    res.json({ success: true, data: { ...user, purchases } });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/users/:userId', authMiddleware, async (req, res) => {
  try {
    const { balance, level, exp, isBanned, banReason, notes } = req.body;
    const updates = {};
    
    if (balance !== undefined) updates.balance = parseInt(balance);
    if (level !== undefined) updates.level = parseInt(level);
    if (exp !== undefined) updates.exp = parseInt(exp);
    if (isBanned !== undefined) updates.isBanned = Boolean(isBanned);
    if (banReason !== undefined) updates.banReason = banReason;
    if (notes !== undefined) updates.notes = notes;

    const user = await db.updateUser(req.params.userId, updates);
    if (!user) return res.status(404).json({ success: false, error: 'User tidak ditemukan' });
    
    res.json({ success: true, data: user, message: 'User berhasil diupdate' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/users/:userId/add-balance', authMiddleware, async (req, res) => {
  try {
    const user = await db.getUser(req.params.userId);
    if (!user) return res.status(404).json({ success: false, error: 'User tidak ditemukan' });

    const amount = parseInt(req.body.amount);
    if (isNaN(amount)) return res.status(400).json({ success: false, error: 'Amount tidak valid' });

    const newBalance = user.balance + amount;
    const updated = await db.updateUser(req.params.userId, { balance: newBalance });
    
    res.json({ success: true, data: updated, message: `Saldo berhasil ditambah ${helpers.formatCurrency(amount)}` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── PRODUCT ROUTES ───────────────────────────────────────────────────────────
app.get('/api/products', authMiddleware, async (req, res) => {
  try {
    const products = await db.getAllProducts(false);
    res.json({ success: true, data: products, total: products.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/products/:productId', authMiddleware, async (req, res) => {
  try {
    const product = await db.getProduct(req.params.productId);
    if (!product) return res.status(404).json({ success: false, error: 'Produk tidak ditemukan' });
    res.json({ success: true, data: product });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/products', authMiddleware, upload.single('image'), async (req, res) => {
  try {
    const { name, description, price, stock, category, postPurchaseInfo } = req.body;
    
    if (!name || !price) {
      return res.status(400).json({ success: false, error: 'Nama dan harga wajib diisi' });
    }

    const productData = {
      name, description, price, stock, category, postPurchaseInfo,
      image: req.file ? req.file.path : null
    };

    const product = await db.createProduct(productData);
    res.json({ success: true, data: product, message: 'Produk berhasil ditambah' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/products/:productId', authMiddleware, upload.single('image'), async (req, res) => {
  try {
    const { name, description, price, stock, category, postPurchaseInfo, active } = req.body;
    const updates = {};

    if (name !== undefined) updates.name = name;
    if (description !== undefined) updates.description = description;
    if (price !== undefined) updates.price = parseInt(price);
    if (stock !== undefined) updates.stock = parseInt(stock);
    if (category !== undefined) updates.category = category;
    if (postPurchaseInfo !== undefined) updates.postPurchaseInfo = postPurchaseInfo;
    if (active !== undefined) updates.active = active === 'true' || active === true;
    if (req.file) updates.image = req.file.path;

    const product = await db.updateProduct(req.params.productId, updates);
    if (!product) return res.status(404).json({ success: false, error: 'Produk tidak ditemukan' });
    
    res.json({ success: true, data: product, message: 'Produk berhasil diupdate' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/products/:productId', authMiddleware, async (req, res) => {
  try {
    const success = await db.deleteProduct(req.params.productId);
    if (!success) return res.status(404).json({ success: false, error: 'Produk tidak ditemukan' });
    res.json({ success: true, message: 'Produk berhasil dihapus' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── TOPUP ROUTES ─────────────────────────────────────────────────────────────
app.get('/api/topups', authMiddleware, async (req, res) => {
  try {
    const topups = await db.getAllTopups();
    res.json({ success: true, data: topups, total: topups.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/topups/pending', authMiddleware, async (req, res) => {
  try {
    const topups = await db.getPendingTopups();
    
    // Enrich with user data
    const enriched = await Promise.all(topups.map(async topup => {
      const user = await db.getUser(topup.userId);
      return { ...topup, user };
    }));
    
    res.json({ success: true, data: enriched, total: enriched.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/topups/:topupId/approve', authMiddleware, async (req, res) => {
  try {
    const result = await db.approveTopup(req.params.topupId, 'admin-dashboard');
    if (!result.success) return res.status(400).json({ success: false, error: result.error });
    res.json({ success: true, message: 'Topup berhasil dikonfirmasi' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/topups/:topupId/reject', authMiddleware, async (req, res) => {
  try {
    const result = await db.rejectTopup(req.params.topupId, 'admin-dashboard', req.body.reason);
    if (!result.success) return res.status(400).json({ success: false, error: result.error });
    res.json({ success: true, message: 'Topup berhasil ditolak' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── SETTINGS ROUTES ──────────────────────────────────────────────────────────
app.get('/api/settings', authMiddleware, async (req, res) => {
  try {
    const settings = await db.getSettings();
    res.json({ success: true, data: settings });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/settings', authMiddleware, async (req, res) => {
  try {
    const settings = await db.updateSettings(req.body);
    res.json({ success: true, data: settings, message: 'Pengaturan berhasil disimpan' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Upload bot files (QRIS, tag image, tag audio)
app.post('/api/settings/upload', authMiddleware, upload.fields([
  { name: 'qrisImage', maxCount: 1 },
  { name: 'tagImage', maxCount: 1 },
  { name: 'tagAudio', maxCount: 1 }
]), async (req, res) => {
  try {
    const updates = {};
    
    if (req.files.qrisImage) updates.qrisImage = req.files.qrisImage[0].path;
    if (req.files.tagImage) updates.tagImage = req.files.tagImage[0].path;
    if (req.files.tagAudio) updates.tagAudio = req.files.tagAudio[0].path;

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada file yang diupload' });
    }

    const settings = await db.updateSettings(updates);
    res.json({ success: true, data: settings, message: 'File berhasil diupload' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── LOGS ROUTES ──────────────────────────────────────────────────────────────
app.get('/api/logs', authMiddleware, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100;
    const logs = await db.getLogs(limit);
    res.json({ success: true, data: logs });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── SERVE ADMIN DASHBOARD ────────────────────────────────────────────────────
app.get('/admin*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/', (req, res) => {
  res.redirect('/admin');
});

// ─── START SERVER ─────────────────────────────────────────────────────────────
async function startServer() {
  await db.initDatabase();
  
  app.listen(PORT, '0.0.0.0', () => {
    const os = require('os');
    const nets = os.networkInterfaces();
    const ips = [];
    Object.values(nets).forEach(n => (n || []).forEach(i => {
      if (i.family === 'IPv4' && !i.internal) ips.push(i.address);
    }));
    const ip = ips[0] || 'YOUR_SERVER_IP';
    console.log(`🌐 Dashboard lokal  : http://localhost:${PORT}/admin`);
    console.log(`🌐 Dashboard via IP : http://${ip}:${PORT}/admin`);
    console.log(`🔐 Password         : ${ADMIN_PASSWORD}`);
  });
}

startServer().catch(console.error);

module.exports = app;
