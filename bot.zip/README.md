# 🛒 Telegram Store Bot + Admin Dashboard

Bot Telegram toko digital lengkap dengan sistem topup, pembelian, dan admin dashboard berbasis web.

---

## 📁 Struktur File

```
telegram-store/
├── bot/
│   ├── index.js          # Main bot Telegraf
│   ├── database.js       # Database manager (JSON)
│   └── helpers.js        # Helper utilities
├── public/
│   └── admin.html        # Admin Dashboard (Web UI)
├── data/                 # Data tersimpan disini (auto-created)
│   ├── users.json
│   ├── products.json
│   ├── transactions.json
│   ├── topups.json
│   ├── purchases.json
│   ├── settings.json
│   ├── logs.json
│   └── proofs/           # Bukti transfer user
├── server.js             # Express server untuk dashboard
├── package.json
├── .env                  # Konfigurasi (EDIT INI!)
└── README.md
```

---

## 🚀 Setup & Instalasi

### 1. Install Dependencies
```bash
npm install
```

### 2. Konfigurasi .env
Edit file `.env`:
```env
BOT_TOKEN=token_bot_anda_dari_botfather
ADMIN_IDS=id_telegram_anda
BOT_NAME=🛒 Nama Toko Anda
ADMIN_PASSWORD=password_dashboard_admin
PORT=3000
```

**Cara dapat BOT_TOKEN:**
1. Chat @BotFather di Telegram
2. Kirim `/newbot`
3. Ikuti instruksi
4. Copy token yang diberikan

**Cara dapat ADMIN_IDS:**
1. Chat @userinfobot di Telegram
2. Kirim `/start`
3. Copy ID Anda

### 3. Jalankan Bot
```bash
# Jalankan bot saja
npm start

# Jalankan server admin dashboard saja
npm run server

# Jalankan keduanya bersamaan
npm run all
```

---

## 🤖 Fitur Bot Telegram

### Menu User
- `/start` - Menu utama + kirim tag image & audio
- 🛍️ Store - Lihat & beli produk
- 💰 Top Up - Isi saldo (multi metode pembayaran)
- 👤 Profil - Level, saldo, statistik user
- 📦 Pembelian - Riwayat & detail produk yang dibeli
- ℹ️ Informasi - Info tentang bot
- 👥 Grup - Link grup & channel

### Sistem Topup
1. User pilih metode pembayaran
2. Input nominal topup
3. Tampil instruksi transfer + QRIS (jika ada)
4. User kirim bukti transfer (foto)
5. Admin terima notifikasi + gambar bukti
6. Admin approve/reject via bot atau dashboard
7. Saldo user otomatis bertambah jika approved

### Sistem Level
- 🌱 Level 1 - Newcomer (0-100 EXP)
- ⭐ Level 2 - Member (100-500 EXP)
- 💫 Level 3 - Regular (500-1500 EXP)
- 👑 Level 4 - VIP (1500-5000 EXP)
- 🏆 Level 5 - Legend (5000+ EXP)

EXP didapat dari: topup + pembelian

---

## 🌐 Admin Dashboard

Akses: `http://localhost:3000/admin`

### Fitur Dashboard
- 📊 **Dashboard** - Statistik real-time
- 💳 **Top Up** - Kelola & approve/reject topup
- 📦 **Produk** - Add/Edit/Hapus produk
- 👥 **Users** - Edit user (level, saldo, ban)
- 🛒 **Pembelian** - Riwayat semua transaksi
- ⚙️ **Pengaturan** - Konfigurasi bot lengkap
- 📋 **Logs** - Activity log sistem

### Pengaturan Yang Bisa Diubah
- Nama bot, teks selamat datang, info bot
- Metode pembayaran & nomor rekening
- Upload QRIS image, tag image, tag audio
- Konfigurasi level & EXP
- Mode maintenance
- Link grup & channel
- Edit semua data user

---

## 📝 Catatan Penting

1. **Database**: Semua data disimpan dalam file JSON di folder `data/`
2. **Backup**: Backup folder `data/` secara berkala
3. **Port**: Default 3000, bisa diubah di .env
4. **Gambar**: Upload via dashboard, otomatis tersimpan di `data/uploads/`

---

## 🔧 Command Admin Bot

Ketik `/admin` di chat bot untuk akses panel admin via bot:
- Lihat topup pending
- Approve/reject topup
- Statistik bot

---

## ⚠️ Security

- Jangan share `BOT_TOKEN` ke siapapun
- Ganti `ADMIN_PASSWORD` dengan password yang kuat
- `ADMIN_IDS` hanya masukkan ID Telegram yang terpercaya
- File `.env` jangan di-commit ke Git (sudah ada di .gitignore)

---

## 📞 Support

Ada masalah? Silakan buat issue atau hubungi developer.

---

**Version 2.0.0** | Made with ❤️ for Indonesian Telegram Sellers
