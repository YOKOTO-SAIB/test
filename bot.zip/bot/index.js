/**
 * =====================================================
 * TELEGRAM STORE BOT - MAIN FILE (FIXED)
 * =====================================================
 * Fix:
 * - Semua pesan pakai HTML parse_mode (bukan Markdown)
 *   sehingga karakter _ ( ) . dll AMAN
 * - Tag image/audio dikirim dengan file_id (disimpan di settings)
 * - Profile fix: reply baru, bukan editMessage
 * - Welcome: kirim foto dulu (caption=menu), lalu audio
 * - Download bukti transfer via streaming
 * - Server listen 0.0.0.0 agar bisa diakses via IP
 * =====================================================
 */

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const { Telegraf } = require('telegraf');
const path = require('path');
const fs = require('fs-extra');
const https = require('https');
const http = require('http');

const db = require('./database');
const h = require('./helpers');

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const BOT_TOKEN = process.env.BOT_TOKEN || '';
const ADMIN_IDS = process.env.ADMIN_IDS || '';

if (!BOT_TOKEN || BOT_TOKEN === 'YOUR_BOT_TOKEN_HERE') {
  console.error('❌ BOT_TOKEN belum diisi di .env!');
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

// ─── STATE MAP ────────────────────────────────────────────────────────────────
const userStates = new Map();

function setState(uid, state, data = {}) {
  userStates.set(String(uid), { state, data, ts: Date.now() });
}
function getState(uid) {
  const s = userStates.get(String(uid));
  if (!s) return null;
  if (Date.now() - s.ts > 30 * 60 * 1000) { userStates.delete(String(uid)); return null; }
  return s;
}
function clearState(uid) { userStates.delete(String(uid)); }

// ─── HTML REPLY HELPERS ───────────────────────────────────────────────────────
// Selalu pakai HTML agar karakter spesial aman
function replyHTML(ctx, text, extra = {}) {
  return ctx.reply(text, { parse_mode: 'HTML', ...extra });
}
function editHTML(ctx, text, extra = {}) {
  return ctx.editMessageText(text, { parse_mode: 'HTML', ...extra });
}

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────────
bot.use(async (ctx, next) => {
  if (!ctx.from) return next();
  try {
    ctx.dbUser = await db.createUser(ctx.from);
    ctx.settings = await db.getSettings();

    if (ctx.dbUser.isBanned) {
      return ctx.reply(`🚫 Akun Anda diblokir!\nAlasan: ${ctx.dbUser.banReason || 'Tidak diketahui'}`);
    }
    if (ctx.settings.maintenanceMode && !h.isAdmin(ctx.from.id, ADMIN_IDS)) {
      return ctx.reply(ctx.settings.maintenanceMessage || '🔧 Bot sedang maintenance.');
    }
    return next();
  } catch (err) {
    console.error('Middleware error:', err.message);
    return next();
  }
});

// ─── SEND WELCOME ─────────────────────────────────────────────────────────────
async function sendWelcome(ctx) {
  const user = ctx.dbUser;
  const settings = ctx.settings || await db.getSettings();
  const welcomeText = h.buildWelcomeHTML(user, settings);
  const keyboard = h.buildMainKeyboard();

  // Kirim tag IMAGE (jika ada file_id tersimpan atau file lokal)
  if (settings.tagImageFileId) {
    // Pakai file_id yang sudah disimpan di settings (lebih cepat)
    try {
      await ctx.replyWithPhoto(settings.tagImageFileId, {
        caption: `<b>🛒 ${h.escHtml(settings.botName || 'MyStore Bot')}</b>`,
        parse_mode: 'HTML'
      });
    } catch (e) { console.log('Tag image (fileId) error:', e.message); }
  } else if (settings.tagImage && await fs.pathExists(settings.tagImage)) {
    // Upload dari file lokal, simpan file_id untuk berikutnya
    try {
      const sent = await ctx.replyWithPhoto({ source: settings.tagImage }, {
        caption: `<b>🛒 ${h.escHtml(settings.botName || 'MyStore Bot')}</b>`,
        parse_mode: 'HTML'
      });
      // Simpan file_id agar tidak perlu upload ulang
      const fileId = sent.photo?.[sent.photo.length - 1]?.file_id;
      if (fileId) await db.updateSettings({ tagImageFileId: fileId });
    } catch (e) { console.log('Tag image (file) error:', e.message); }
  }

  // Kirim tag AUDIO (jika ada)
  if (settings.tagAudioFileId) {
    try {
      await ctx.replyWithAudio(settings.tagAudioFileId);
    } catch (e) { console.log('Tag audio (fileId) error:', e.message); }
  } else if (settings.tagAudio && await fs.pathExists(settings.tagAudio)) {
    try {
      const sent = await ctx.replyWithAudio({ source: settings.tagAudio });
      const fileId = sent.audio?.file_id;
      if (fileId) await db.updateSettings({ tagAudioFileId: fileId });
    } catch (e) { console.log('Tag audio (file) error:', e.message); }
  }

  // Kirim welcome message dengan keyboard
  await replyHTML(ctx, welcomeText, { reply_markup: keyboard });
}

// ─── /start ───────────────────────────────────────────────────────────────────
bot.start(async (ctx) => {
  try {
    clearState(ctx.from.id);
    await sendWelcome(ctx);
    console.log(`/start: ${ctx.from.first_name} (${ctx.from.id})`);
  } catch (err) {
    console.error('Start error:', err.message);
    await ctx.reply('❌ Terjadi kesalahan. Coba /start lagi.');
  }
});

// ─── /help ────────────────────────────────────────────────────────────────────
bot.command('help', async (ctx) => {
  await replyHTML(ctx,
    `╔══════════════════════════╗\n║       📚 BANTUAN BOT      ║\n╚══════════════════════════╝\n\n/start - Menu utama\n/admin - Panel admin\n/help - Bantuan ini\n\n❓ Hubungi: ${h.escHtml(ctx.settings?.adminContact || '@admin')}`,
    { reply_markup: h.buildMainKeyboard() }
  );
});

// ─── /admin ───────────────────────────────────────────────────────────────────
bot.command('admin', async (ctx) => {
  if (!h.isAdmin(ctx.from.id, ADMIN_IDS)) return ctx.reply('❌ Bukan admin!');
  const stats = await db.getStats();
  const pending = await db.getPendingTopups();

  await replyHTML(ctx,
    `╔══════════════════════════╗\n║      👑 ADMIN PANEL       ║\n╚══════════════════════════╝\n\n📊 Statistik:\n👥 Users: <b>${stats.totalUsers}</b>\n📦 Produk Aktif: <b>${stats.activeProducts}</b>\n🛒 Total Order: <b>${stats.totalPurchases}</b>\n💰 Revenue: <b>${h.formatCurrency(stats.totalRevenue)}</b>\n⏳ Topup Pending: <b>${pending.length}</b>`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: '⏳ Topup Pending', callback_data: 'admin_pending_topups' }, { text: '📊 Statistik', callback_data: 'admin_stats' }],
          [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]
        ]
      }
    }
  );
});

// ─── CALLBACK HANDLER ─────────────────────────────────────────────────────────
bot.on('callback_query', async (ctx) => {
  const data = ctx.callbackQuery.data;
  const uid = String(ctx.from.id);

  try {
    await ctx.answerCbQuery().catch(() => {});

    // ── MENU MAIN ──
    if (data === 'menu_main') {
      clearState(uid);
      // Hapus pesan lama dan kirim welcome baru
      try { await ctx.deleteMessage(); } catch (_) {}
      return sendWelcome(ctx);
    }

    // ── INFO ──
    if (data === 'menu_info') {
      const settings = ctx.settings || await db.getSettings();
      return editHTML(ctx,
        h.escHtml(settings.aboutText || 'Belum ada info.'),
        { reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]] } }
      );
    }

    // ── GROUP ──
    if (data === 'menu_group') {
      const s = ctx.settings || await db.getSettings();
      const keyboard = { inline_keyboard: [] };
      if (s.channelLink) keyboard.inline_keyboard.push([{ text: '📢 Join Channel', url: s.channelLink }]);
      if (s.groupLink) keyboard.inline_keyboard.push([{ text: '👥 Join Grup', url: s.groupLink }]);
      keyboard.inline_keyboard.push([{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]);

      return editHTML(ctx,
        `╔══════════════════════════╗\n║    👥 KOMUNITAS KAMI      ║\n╚══════════════════════════╝\n\n📢 Channel: ${h.escHtml(s.channelLink || 'Belum ada')}\n👥 Grup: ${h.escHtml(s.groupLink || 'Belum ada')}`,
        { reply_markup: keyboard }
      );
    }

    // ── STORE ──
    if (data === 'menu_store' || data.startsWith('store_page_')) {
      const page = data.startsWith('store_page_') ? parseInt(data.split('_')[2]) : 0;
      const products = await db.getAllProducts(true);

      if (products.length === 0) {
        return editHTML(ctx, '🛒 Belum ada produk tersedia.',
          { reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]] } }
        );
      }

      return editHTML(ctx,
        `╔══════════════════════════╗\n║       🛒 TOKO KAMI        ║\n╚══════════════════════════╝\n\n🟢 = Tersedia  🔴 = Habis\n\nPilih produk untuk detail:`,
        { reply_markup: h.buildProductListKeyboard(products, page) }
      );
    }

    // ── PRODUCT DETAIL ──
    if (data.startsWith('product_')) {
      const productId = data.replace('product_', '');
      const product = await db.getProduct(productId);
      if (!product) return ctx.answerCbQuery('❌ Produk tidak ditemukan', { show_alert: true });

      const msg = h.buildProductHTML(product);
      const keyboard = h.buildProductDetailKeyboard(product);

      // Coba kirim dengan gambar jika ada
      if (product.image && await fs.pathExists(product.image)) {
        try {
          await ctx.deleteMessage();
          await ctx.replyWithPhoto({ source: product.image }, {
            caption: msg, parse_mode: 'HTML', reply_markup: keyboard
          });
          return;
        } catch (e) {}
      }
      return editHTML(ctx, msg, { reply_markup: keyboard });
    }

    // ── BUY CONFIRM DIALOG ──
    if (data.startsWith('buy_') && !data.startsWith('buy_confirm')) {
      const productId = data.replace('buy_', '');
      const product = await db.getProduct(productId);
      const user = ctx.dbUser;

      if (!product) return ctx.answerCbQuery('❌ Produk tidak ditemukan', { show_alert: true });
      if (product.stock <= 0) return ctx.answerCbQuery('❌ Stok habis!', { show_alert: true });

      const cukup = user.balance >= product.price;
      const msg = `╔══════════════════════════╗\n║   🛒 KONFIRMASI BELI     ║\n╚══════════════════════════╝\n\n📦 Produk: <b>${h.escHtml(product.name)}</b>\n💰 Harga: <b>${h.formatCurrency(product.price)}</b>\n💳 Saldo Anda: <b>${h.formatCurrency(user.balance)}</b>\n💳 Sisa Saldo: <b>${h.formatCurrency(user.balance - product.price)}</b>\n\n${cukup ? '✅ Saldo mencukupi. Lanjutkan?' : '❌ <b>SALDO TIDAK MENCUKUPI!</b>\nSilakan topup terlebih dahulu.'}`;

      const keyboard = cukup
        ? h.buildBuyConfirmKeyboard(productId)
        : { inline_keyboard: [[{ text: '💰 Top Up Sekarang', callback_data: 'menu_topup' }], [{ text: '◀️ Kembali', callback_data: `product_${productId}` }]] };

      return editHTML(ctx, msg, { reply_markup: keyboard });
    }

    // ── CONFIRM BUY ──
    if (data.startsWith('confirm_buy_')) {
      const productId = data.replace('confirm_buy_', '');
      const result = await db.createPurchase(uid, productId);

      if (!result.success) return ctx.answerCbQuery(`❌ ${result.error}`, { show_alert: true });

      const updatedUser = await db.getUser(uid);
      ctx.dbUser = updatedUser;

      return editHTML(ctx,
        h.buildPurchaseSuccessHTML(result.product, result.purchase, result.expGained, updatedUser.balance),
        { reply_markup: { inline_keyboard: [[{ text: '🛒 Belanja Lagi', callback_data: 'menu_store' }], [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]] } }
      );
    }

    // ── PROFILE ──
    if (data === 'menu_profile') {
      const user = ctx.dbUser;
      const levelConfig = await db.getUserLevel(user);
      const msg = h.buildProfileHTML(user, levelConfig);

      // Profile: reply baru karena kadang pesan sebelumnya photo
      try {
        await editHTML(ctx, msg, {
          reply_markup: {
            inline_keyboard: [
              [{ text: '💰 Top Up', callback_data: 'menu_topup' }, { text: '📦 Pembelian', callback_data: 'menu_purchases' }],
              [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]
            ]
          }
        });
      } catch (e) {
        // Jika gagal edit (misalnya pesan adalah foto), kirim baru
        try { await ctx.deleteMessage(); } catch (_) {}
        await replyHTML(ctx, msg, {
          reply_markup: {
            inline_keyboard: [
              [{ text: '💰 Top Up', callback_data: 'menu_topup' }, { text: '📦 Pembelian', callback_data: 'menu_purchases' }],
              [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]
            ]
          }
        });
      }
      return;
    }

    // ── PURCHASES ──
    if (data === 'menu_purchases' || data.startsWith('purchases_page_')) {
      const page = data.startsWith('purchases_page_') ? parseInt(data.split('_')[2]) : 0;
      const purchases = await db.getUserPurchases(uid);

      if (purchases.length === 0) {
        const msg = `╔══════════════════════════╗\n║    📦 RIWAYAT PEMBELIAN   ║\n╚══════════════════════════╝\n\n📭 Belum ada pembelian.\n\nYuk belanja di toko kami!`;
        try {
          return await editHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '🛒 Ke Store', callback_data: 'menu_store' }], [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]] } });
        } catch (_) {
          try { await ctx.deleteMessage(); } catch (__) {}
          return replyHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '🛒 Ke Store', callback_data: 'menu_store' }]] } });
        }
      }

      const msg = `╔══════════════════════════╗\n║    📦 RIWAYAT PEMBELIAN   ║\n╚══════════════════════════╝\n\n🛒 Total: <b>${purchases.length} item</b>\n\nPilih untuk lihat detail:`;
      try {
        return await editHTML(ctx, msg, { reply_markup: h.buildPurchaseListKeyboard(purchases, page) });
      } catch (_) {
        try { await ctx.deleteMessage(); } catch (__) {}
        return replyHTML(ctx, msg, { reply_markup: h.buildPurchaseListKeyboard(purchases, page) });
      }
    }

    // ── PURCHASE DETAIL ──
    if (data.startsWith('purchase_detail_')) {
      const purchaseId = data.replace('purchase_detail_', '');
      const purchases = await db.getUserPurchases(uid);
      const purchase = purchases.find(p => p.id === purchaseId);
      if (!purchase) return ctx.answerCbQuery('❌ Data tidak ditemukan', { show_alert: true });

      const msg = h.buildPurchaseDetailHTML(purchase);
      try {
        return await editHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'menu_purchases' }], [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]] } });
      } catch (_) {
        try { await ctx.deleteMessage(); } catch (__) {}
        return replyHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '◀️ Kembali', callback_data: 'menu_purchases' }]] } });
      }
    }

    // ── TOPUP MENU ──
    if (data === 'menu_topup') {
      const settings = ctx.settings || await db.getSettings();
      const user = ctx.dbUser;

      // Cek pending topup
      if (user.pendingTopup) {
        const pending = await db.getTopup(user.pendingTopup);
        if (pending && pending.status === 'pending') {
          const keyboard = {
            inline_keyboard: [
              ...(!pending.proofImage ? [[{ text: '📸 Kirim Bukti', callback_data: `topup_sendproof_${pending.id}` }]] : []),
              [{ text: '❌ Batalkan', callback_data: `topup_cancel_${pending.id}` }],
              [{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]
            ]
          };
          const msg = `╔══════════════════════════╗\n║   ⏳ TOPUP SEDANG PROSES  ║\n╚══════════════════════════╝\n\n🆔 ID: <code>${pending.id}</code>\n💰 Nominal: <b>${h.formatCurrency(pending.amount)}</b>\n💳 Metode: <b>${h.escHtml(pending.method)}</b>\n\n${pending.proofImage ? '📸 Bukti sudah dikirim, tunggu konfirmasi admin' : '⚠️ Bukti belum dikirim!'}`;
          try { return await editHTML(ctx, msg, { reply_markup: keyboard }); } catch (_) {
            try { await ctx.deleteMessage(); } catch (__) {}
            return replyHTML(ctx, msg, { reply_markup: keyboard });
          }
        } else {
          await db.updateUser(uid, { pendingTopup: null });
        }
      }

      const msg = `╔══════════════════════════╗\n║       💰 TOP UP SALDO     ║\n╚══════════════════════════╝\n\n💳 Saldo Anda: <b>${h.formatCurrency(user.balance)}</b>\n\nPilih metode pembayaran:\n\nMin: <b>${h.formatCurrency(settings.minTopup || 10000)}</b>\nMax: <b>${h.formatCurrency(settings.maxTopup || 10000000)}</b>`;

      try {
        return await editHTML(ctx, msg, { reply_markup: h.buildTopupMethodKeyboard(settings.paymentMethods || ['DANA', 'OVO']) });
      } catch (_) {
        try { await ctx.deleteMessage(); } catch (__) {}
        return replyHTML(ctx, msg, { reply_markup: h.buildTopupMethodKeyboard(settings.paymentMethods || ['DANA', 'OVO']) });
      }
    }

    // ── TOPUP METHOD SELECTED ──
    if (data.startsWith('topup_method_')) {
      const method = data.replace('topup_method_', '');
      setState(uid, 'waiting_topup_amount', { method });

      const settings = ctx.settings || await db.getSettings();
      const paymentNumber = settings.paymentNumbers?.[method] || 'Tidak tersedia';
      const msg = `╔══════════════════════════╗\n║   💰 INPUT NOMINAL TOPUP  ║\n╚══════════════════════════╝\n\n💳 Metode: <b>${h.escHtml(method)}</b>\n📲 Nomor: <code>${h.escHtml(paymentNumber)}</code>\n👤 A.N: <b>${h.escHtml(settings.paymentOwner || 'Admin')}</b>\n\n⬆️ <b>Ketik nominal topup di chat:</b>\nContoh: <code>50000</code>\n\nMin: ${h.formatCurrency(settings.minTopup || 10000)}\nMax: ${h.formatCurrency(settings.maxTopup || 10000000)}`;

      try { return await editHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_topup' }]] } }); }
      catch (_) { return replyHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_topup' }]] } }); }
    }

    // ── TOPUP SEND PROOF ──
    if (data.startsWith('topup_sendproof_')) {
      const topupId = data.replace('topup_sendproof_', '');
      setState(uid, 'waiting_topup_proof', { topupId });
      const msg = `📸 <b>Kirim Foto Bukti Transfer!</b>\n\nUpload foto/screenshot bukti pembayaran Anda sekarang.\n\n⚠️ Hanya gambar yang diterima.`;
      try { return await editHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: `topup_cancel_${topupId}` }]] } }); }
      catch (_) { return replyHTML(ctx, msg, { reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: `topup_cancel_${topupId}` }]] } }); }
    }

    // ── TOPUP CANCEL ──
    if (data.startsWith('topup_cancel_')) {
      const topupId = data.replace('topup_cancel_', '');
      await db.updateTopup(topupId, { status: 'cancelled' });
      await db.updateUser(uid, { pendingTopup: null });
      clearState(uid);
      const msg = '❌ <b>Topup dibatalkan.</b>';
      try { return await editHTML(ctx, msg, { reply_markup: h.buildMainKeyboard() }); }
      catch (_) { return replyHTML(ctx, msg, { reply_markup: h.buildMainKeyboard() }); }
    }

    // ── STOCK EMPTY ──
    if (data === 'stock_empty') {
      return ctx.answerCbQuery('❌ Maaf, stok habis!', { show_alert: true });
    }

    // ── ADMIN CALLBACKS ──
    if (data.startsWith('admin_') && h.isAdmin(ctx.from.id, ADMIN_IDS)) {

      // Admin approve topup
      if (data.startsWith('admin_approve_')) {
        const topupId = data.replace('admin_approve_', '');
        const result = await db.approveTopup(topupId, uid);
        if (!result.success) return ctx.answerCbQuery('❌ ' + result.error, { show_alert: true });

        const updatedUser = await db.getUser(result.topup.userId);
        // Update caption admin message
        try {
          await ctx.editMessageCaption(
            `✅ <b>TOPUP DISETUJUI!</b>\n\nID: <code>${topupId}</code>\nNominal: <b>${h.formatCurrency(result.topup.amount)}</b>\nDisetujui oleh: ${h.escHtml(ctx.from.first_name)}`,
            { parse_mode: 'HTML' }
          );
        } catch (_) {
          try { await ctx.editMessageText(`✅ Topup <code>${topupId}</code> disetujui!`, { parse_mode: 'HTML' }); } catch (__) {}
        }

        // Notif ke user
        try {
          await bot.telegram.sendMessage(result.topup.userId,
            `✅ <b>TOPUP BERHASIL!</b>\n\n💰 Nominal: <b>${h.formatCurrency(result.topup.amount)}</b>\n💳 Saldo Baru: <b>${h.formatCurrency(updatedUser.balance)}</b>\n\nTerima kasih! 🎉`,
            { parse_mode: 'HTML', reply_markup: h.buildMainKeyboard() }
          );
        } catch (e) { console.log('Notify user error:', e.message); }
        return;
      }

      // Admin reject topup
      if (data.startsWith('admin_reject_')) {
        const topupId = data.replace('admin_reject_', '');
        const result = await db.rejectTopup(topupId, uid);
        if (!result.success) return ctx.answerCbQuery('❌ ' + result.error, { show_alert: true });

        try {
          await ctx.editMessageCaption(
            `❌ <b>TOPUP DITOLAK!</b>\n\nID: <code>${topupId}</code>\nDitolak oleh: ${h.escHtml(ctx.from.first_name)}`,
            { parse_mode: 'HTML' }
          );
        } catch (_) {
          try { await ctx.editMessageText(`❌ Topup <code>${topupId}</code> ditolak!`, { parse_mode: 'HTML' }); } catch (__) {}
        }

        try {
          await bot.telegram.sendMessage(result.topup.userId,
            `❌ <b>TOPUP DITOLAK!</b>\n\n💰 Nominal: <b>${h.formatCurrency(result.topup.amount)}</b>\nAlasan: Bukti transfer tidak valid.\n\nSilakan coba lagi dengan bukti yang benar.`,
            { parse_mode: 'HTML', reply_markup: h.buildMainKeyboard() }
          );
        } catch (e) {}
        return;
      }

      // Admin pending topups list
      if (data === 'admin_pending_topups') {
        const pending = await db.getPendingTopups();
        if (pending.length === 0) return ctx.answerCbQuery('✅ Tidak ada topup pending', { show_alert: true });

        for (const topup of pending.slice(0, 5)) {
          const user = await db.getUser(topup.userId);
          if (!user) continue;
          const adminMsg = h.buildAdminTopupHTML(user, topup);
          const keyboard = h.buildAdminTopupKeyboard(topup.id);

          if (topup.proofImage && await fs.pathExists(topup.proofImage)) {
            await bot.telegram.sendPhoto(ctx.from.id, { source: topup.proofImage }, {
              caption: adminMsg, parse_mode: 'HTML', reply_markup: keyboard
            });
          } else {
            await bot.telegram.sendMessage(ctx.from.id, adminMsg, { parse_mode: 'HTML', reply_markup: keyboard });
          }
        }
        return;
      }

      // Admin stats
      if (data === 'admin_stats') {
        const stats = await db.getStats();
        return editHTML(ctx,
          `📊 <b>STATISTIK BOT</b>\n\n👥 Users: <b>${stats.totalUsers}</b>\n✅ Aktif: <b>${stats.activeUsers}</b>\n📦 Produk: <b>${stats.activeProducts}</b>\n🛒 Orders: <b>${stats.totalPurchases}</b>\n💰 Revenue: <b>${h.formatCurrency(stats.totalRevenue)}</b>\n⏳ Pending: <b>${stats.pendingTopups}</b>`,
          { reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]] } }
        );
      }
    }

  } catch (err) {
    console.error('Callback error:', err.message, '\nData:', data);
    await ctx.answerCbQuery('❌ Terjadi kesalahan', { show_alert: true }).catch(() => {});
  }
});

// ─── MESSAGE HANDLER ──────────────────────────────────────────────────────────
bot.on('message', async (ctx) => {
  const uid = String(ctx.from.id);
  const stateData = getState(uid);
  if (!stateData) return;

  const { state, data } = stateData;
  const settings = ctx.settings || await db.getSettings();

  // ── WAITING TOPUP AMOUNT ──
  if (state === 'waiting_topup_amount') {
    if (!ctx.message.text) return ctx.reply('⚠️ Kirim angka nominal saja, contoh: 50000');

    const amount = parseInt(ctx.message.text.replace(/[^0-9]/g, ''));
    const min = settings.minTopup || 10000;
    const max = settings.maxTopup || 10000000;

    if (!h.isValidAmount(amount, min, max)) {
      return replyHTML(ctx,
        `❌ Nominal tidak valid!\n\nMin: <b>${h.formatCurrency(min)}</b>\nMax: <b>${h.formatCurrency(max)}</b>\n\nCoba lagi:`,
        { reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_topup' }]] } }
      );
    }

    const method = data.method;
    const paymentNumber = settings.paymentNumbers?.[method] || '-';
    const ownerName = settings.paymentOwner || 'Admin';

    const topup = await db.createTopup(uid, amount, method, paymentNumber);
    clearState(uid);

    // Kirim QRIS jika ada
    if (settings.qrisImage && await fs.pathExists(settings.qrisImage)) {
      try { await ctx.replyWithPhoto({ source: settings.qrisImage }, { caption: '📷 Scan QRIS untuk pembayaran' }); }
      catch (e) {}
    } else if (settings.qrisImageFileId) {
      try { await ctx.replyWithPhoto(settings.qrisImageFileId, { caption: '📷 Scan QRIS untuk pembayaran' }); }
      catch (e) {}
    }

    return replyHTML(ctx,
      h.buildTopupHTML(amount, method, paymentNumber, ownerName, topup.id),
      { reply_markup: h.buildTopupConfirmKeyboard(topup.id) }
    );
  }

  // ── WAITING TOPUP PROOF ──
  if (state === 'waiting_topup_proof') {
    const topupId = data.topupId;

    if (!ctx.message.photo && !ctx.message.document) {
      return ctx.reply('📸 Kirim FOTO bukti transfer ya! Bukan teks.');
    }

    const topup = await db.getTopup(topupId);
    if (!topup || topup.status !== 'pending') {
      clearState(uid);
      return ctx.reply('❌ Topup tidak valid atau sudah expired.');
    }

    // Ambil file_id
    let fileId;
    if (ctx.message.photo) {
      fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
    } else {
      fileId = ctx.message.document.file_id;
    }

    // Download dan simpan bukti
    const proofDir = path.join(__dirname, '../data/proofs');
    await fs.ensureDir(proofDir);
    const proofPath = path.join(proofDir, `${topupId}.jpg`);

    try {
      const fileLink = await ctx.telegram.getFileLink(fileId);
      const url = fileLink.href || fileLink.toString();
      const protocol = url.startsWith('https') ? https : http;

      await new Promise((resolve, reject) => {
        const fileStream = fs.createWriteStream(proofPath);
        protocol.get(url, (res) => {
          res.pipe(fileStream);
          fileStream.on('finish', () => { fileStream.close(); resolve(); });
          fileStream.on('error', reject);
        }).on('error', reject);
      });
    } catch (e) {
      console.log('Download proof error:', e.message);
      // Simpan file_id saja jika download gagal
      await db.updateTopup(topupId, { proofFileId: fileId });
    }

    await db.updateTopup(topupId, { proofImage: proofPath });
    clearState(uid);

    await replyHTML(ctx,
      `✅ <b>Bukti transfer diterima!</b>\n\n🆔 ID Topup: <code>${topupId}</code>\n⏳ Menunggu konfirmasi admin...\n\nEst. waktu: 5-15 menit`,
      { reply_markup: h.buildMainKeyboard() }
    );

    // Kirim ke semua admin
    const user = ctx.dbUser;
    const adminMsg = h.buildAdminTopupHTML(user, topup);
    const adminKeyboard = h.buildAdminTopupKeyboard(topupId);
    const adminList = String(ADMIN_IDS).split(',').map(id => id.trim()).filter(Boolean);

    for (const adminId of adminList) {
      try {
        if (await fs.pathExists(proofPath)) {
          await bot.telegram.sendPhoto(adminId, { source: proofPath }, {
            caption: adminMsg, parse_mode: 'HTML', reply_markup: adminKeyboard
          });
        } else {
          // Fallback: forward gambar langsung via file_id
          await bot.telegram.sendPhoto(adminId, fileId, {
            caption: adminMsg, parse_mode: 'HTML', reply_markup: adminKeyboard
          });
        }
      } catch (e) {
        console.log(`Notify admin ${adminId} error:`, e.message);
        // Fallback text only
        try {
          await bot.telegram.sendMessage(adminId, adminMsg + '\n\n⚠️ Bukti tidak bisa ditampilkan, cek dashboard.', {
            parse_mode: 'HTML', reply_markup: adminKeyboard
          });
        } catch (_) {}
      }
    }
    return;
  }
});

// ─── ERROR HANDLER ────────────────────────────────────────────────────────────
bot.catch((err, ctx) => {
  console.error('Bot error:', err.message);
  if (ctx) ctx.reply('❌ Error internal. Coba /start').catch(() => {});
});

// ─── LAUNCH ───────────────────────────────────────────────────────────────────
async function launch() {
  await db.initDatabase();
  await bot.launch();
  console.log('✅ Bot aktif!');
  console.log(`👑 Admin IDs: ${ADMIN_IDS}`);
}

launch().catch(err => { console.error('Launch error:', err); process.exit(1); });
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

module.exports = bot;
