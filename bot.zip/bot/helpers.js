/**
 * =====================================================
 * HELPER UTILITIES - FIXED VERSION
 * Semua message pakai HTML parse_mode agar aman
 * dari karakter spesial seperti _ ( ) . ! dll
 * =====================================================
 */

const moment = require('moment');
moment.locale('id');

// ─── FORMATTING ───────────────────────────────────────────────────────────────
function formatCurrency(amount) {
  return `Rp${parseInt(amount || 0).toLocaleString('id-ID')}`;
}
function formatDate(dateStr) {
  return moment(dateStr).format('DD MMMM YYYY, HH:mm');
}
function formatDateShort(dateStr) {
  return moment(dateStr).format('DD/MM/YY HH:mm');
}
function formatRelativeTime(dateStr) {
  return moment(dateStr).fromNow();
}
function formatNumber(num) {
  return parseInt(num || 0).toLocaleString('id-ID');
}

// ─── HTML ESCAPE (WAJIB untuk semua teks dari user/db) ────────────────────────
function escHtml(text) {
  if (text === null || text === undefined) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─── PROGRESS BAR ─────────────────────────────────────────────────────────────
function createProgressBar(current, max, length = 10) {
  if (!max || max <= 0) return '░'.repeat(length);
  const pct = Math.min(current / max, 1);
  const filled = Math.round(pct * length);
  return '█'.repeat(filled) + '░'.repeat(length - filled);
}

// ─── LEVEL HELPERS ────────────────────────────────────────────────────────────
function getLevelBadge(level) {
  return { 1:'🌱', 2:'⭐', 3:'💫', 4:'👑', 5:'🏆' }[level] || '🌱';
}
function getLevelName(level) {
  return { 1:'Newcomer', 2:'Member', 3:'Regular', 4:'VIP', 5:'Legend' }[level] || 'Newcomer';
}

// ─── USER HELPERS ─────────────────────────────────────────────────────────────
function getUserName(user) {
  return [user.firstName, user.lastName].filter(Boolean).join(' ') || 'Unknown User';
}
function getUserMention(user) {
  if (user.username) return `@${user.username}`;
  return getUserName(user);
}
function isAdmin(userId, adminIds) {
  return String(adminIds).split(',').map(id => id.trim()).includes(String(userId));
}
function isValidAmount(amount, min = 10000, max = 10000000) {
  const num = parseInt(amount);
  return !isNaN(num) && num >= min && num <= max;
}

// ─── MESSAGE BUILDERS (semua pakai HTML) ──────────────────────────────────────

function buildWelcomeHTML(user, settings) {
  const levelBadge = getLevelBadge(user.level);
  const levelName = getLevelName(user.level);
  const userName = escHtml(getUserName(user));
  const welcomeText = escHtml(settings.welcomeText || 'Selamat datang di toko kami!');

  return `╔══════════════════════════╗
║      🛒 SELAMAT DATANG!   ║
╚══════════════════════════╝

👋 Halo, <b>${userName}</b>!
${levelBadge} Level ${user.level} - ${levelName}

${welcomeText}

━━━━━━━━━━━━━━━━━━━━━━
💰 Saldo: <b>${formatCurrency(user.balance)}</b>
⭐ EXP: <b>${formatNumber(user.exp)}</b>
━━━━━━━━━━━━━━━━━━━━━━

Pilih menu di bawah untuk memulai! 👇`;
}

function buildProfileHTML(user, levelConfig) {
  const userName = escHtml(getUserName(user));
  const expForNextLevel = levelConfig.maxExp || 100;
  const progressBar = createProgressBar(user.exp, expForNextLevel);
  const percentage = Math.min(Math.round((user.exp / expForNextLevel) * 100), 100);

  return `╔══════════════════════════╗
║       👤 PROFIL ANDA      ║
╚══════════════════════════╝

🏷 Nama: <b>${userName}</b>
🆔 ID: <code>${user.id}</code>
📱 Username: ${user.username ? '@' + escHtml(user.username) : 'Tidak ada'}
📅 Bergabung: ${formatDate(user.joinedAt)}

━━━━━━ 📊 STATISTIK ━━━━━━

${levelConfig.badge || '🌱'} Level: <b>${user.level} - ${escHtml(levelConfig.name || 'Newcomer')}</b>
✨ EXP: <b>${formatNumber(user.exp)} / ${formatNumber(expForNextLevel)}</b>
${progressBar} ${percentage}%

💰 Saldo: <b>${formatCurrency(user.balance)}</b>
💳 Total Topup: <b>${formatCurrency(user.totalTopup)}</b>
🛍 Total Belanja: <b>${formatCurrency(user.totalSpent)}</b>
🛒 Total Pembelian: <b>${user.purchaseCount || 0} item</b>

━━━━━━━━━━━━━━━━━━━━━━
👁 Terakhir aktif: ${formatRelativeTime(user.lastSeen)}`;
}

function buildProductHTML(product) {
  const stockStatus = product.stock === 0
    ? '🔴 <b>Habis</b>'
    : product.stock <= 5
      ? `🟡 <b>Hampir Habis</b> (${product.stock})`
      : `🟢 <b>Tersedia</b> (${product.stock})`;

  return `╔══════════════════════════╗
║       🛍 DETAIL PRODUK    ║
╚══════════════════════════╝

📦 <b>${escHtml(product.name)}</b>

📝 Deskripsi:
${escHtml(product.description || '-')}

━━━━━━━━━━━━━━━━━━━━━━

💰 Harga: <b>${formatCurrency(product.price)}</b>
📊 Stok: ${stockStatus}
🛒 Terjual: ${product.sold || 0} item

━━━━━━━━━━━━━━━━━━━━━━`;
}

function buildTopupHTML(amount, method, paymentNumber, ownerName, topupId) {
  return `╔══════════════════════════╗
║      💳 KONFIRMASI TOPUP  ║
╚══════════════════════════╝

📋 Detail Topup:
💰 Nominal: <b>${formatCurrency(amount)}</b>
💳 Metode: <b>${escHtml(method)}</b>
📲 Nomor/Rek: <code>${escHtml(paymentNumber)}</code>
👤 A.N: <b>${escHtml(ownerName)}</b>
🆔 ID Topup: <code>${topupId}</code>

━━━━━━ CARA TRANSFER ━━━━━━

1️⃣ Buka aplikasi <b>${escHtml(method)}</b>
2️⃣ Transfer ke nomor di atas
3️⃣ Nominal: <b>${formatCurrency(amount)}</b>
4️⃣ Simpan bukti transfer
5️⃣ Klik tombol <b>✅ Kirim Bukti</b>
6️⃣ Upload foto bukti transfer
7️⃣ Tunggu konfirmasi admin (max 5 menit)

━━━━━━━━━━━━━━━━━━━━━━
⚠️ Pastikan nominal transfer sesuai!`;
}

function buildAdminTopupHTML(user, topup) {
  const userName = escHtml(getUserName(user));
  return `╔══════════════════════════╗
║   🔔 TOPUP BARU MASUK!   ║
╚══════════════════════════╝

👤 Data Pengguna:
• Nama: <b>${userName}</b>
• Username: ${user.username ? '@' + escHtml(user.username) : 'Tidak ada'}
• ID: <code>${user.id}</code>
• Level: ${getLevelBadge(user.level)} ${getLevelName(user.level)}

━━━━━━ Detail Topup ━━━━━━

💰 Nominal: <b>${formatCurrency(topup.amount)}</b>
💳 Metode: <b>${escHtml(topup.method)}</b>
📲 Ke Nomor: <code>${escHtml(topup.paymentNumber || '-')}</code>
🆔 ID Topup: <code>${topup.id}</code>
⏰ Waktu: ${formatDate(topup.createdAt)}

━━━━━━ Info Akun ━━━━━━

💳 Saldo: <b>${formatCurrency(user.balance)}</b>
🛒 Total Belanja: <b>${formatCurrency(user.totalSpent)}</b>
📊 Jumlah Order: ${user.purchaseCount || 0}

━━━━━━━━━━━━━━━━━━━━━━
📸 Bukti transfer ada di atas ⬆️`;
}

function buildPurchaseSuccessHTML(product, purchase, expGained, newBalance) {
  return `╔══════════════════════════╗
║    ✅ PEMBELIAN BERHASIL! ║
╚══════════════════════════╝

🎉 Selamat! Pembelian berhasil!

📦 Produk: <b>${escHtml(product.name)}</b>
💰 Harga: <b>${formatCurrency(product.price)}</b>
💳 Sisa Saldo: <b>${formatCurrency(newBalance)}</b>
✨ EXP Didapat: +${expGained}
🆔 ID: <code>${purchase.id}</code>
📅 Waktu: ${formatDate(purchase.purchasedAt)}

━━━━━━ INFO PRODUK ━━━━━━

${escHtml(product.postPurchaseInfo || '-')}

━━━━━━━━━━━━━━━━━━━━━━
💡 Simpan informasi ini!
❓ Ada masalah? Hubungi admin`;
}

function buildPurchaseDetailHTML(purchase) {
  return `╔══════════════════════════╗
║    📦 DETAIL PEMBELIAN    ║
╚══════════════════════════╝

🆔 ID: <code>${purchase.id}</code>
📦 Produk: <b>${escHtml(purchase.productName)}</b>
💰 Harga: <b>${formatCurrency(purchase.price)}</b>
📅 Tanggal: ${formatDate(purchase.purchasedAt)}
✅ Status: Berhasil

━━━━━━ INFO PRODUK ━━━━━━

${escHtml(purchase.postPurchaseInfo || '-')}

━━━━━━━━━━━━━━━━━━━━━━
💡 Screenshot untuk referensi!`;
}

// ─── KEYBOARD BUILDERS ────────────────────────────────────────────────────────
function buildMainKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: '🛍 Store', callback_data: 'menu_store' },
        { text: '💰 Top Up', callback_data: 'menu_topup' }
      ],
      [
        { text: '👤 Profil', callback_data: 'menu_profile' },
        { text: '📦 Pembelian', callback_data: 'menu_purchases' }
      ],
      [
        { text: 'ℹ️ Informasi', callback_data: 'menu_info' },
        { text: '👥 Grup', callback_data: 'menu_group' }
      ]
    ]
  };
}

function buildProductListKeyboard(products, page = 0, perPage = 5) {
  const start = page * perPage;
  const pageProducts = products.slice(start, start + perPage);
  const totalPages = Math.ceil(products.length / perPage);

  const buttons = pageProducts.map(product => [{
    text: `${product.stock > 0 ? '🟢' : '🔴'} ${product.name} - ${formatCurrency(product.price)}`,
    callback_data: `product_${product.id}`
  }]);

  const navButtons = [];
  if (page > 0) navButtons.push({ text: '◀️ Sebelumnya', callback_data: `store_page_${page - 1}` });
  if (page < totalPages - 1) navButtons.push({ text: 'Selanjutnya ▶️', callback_data: `store_page_${page + 1}` });
  if (navButtons.length > 0) buttons.push(navButtons);
  buttons.push([{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]);

  return { inline_keyboard: buttons };
}

function buildProductDetailKeyboard(product) {
  const buttons = [];
  if (product.stock > 0) {
    buttons.push([{ text: `💳 Beli - ${formatCurrency(product.price)}`, callback_data: `buy_${product.id}` }]);
  } else {
    buttons.push([{ text: '❌ Stok Habis', callback_data: 'stock_empty' }]);
  }
  buttons.push([
    { text: '◀️ Kembali', callback_data: 'menu_store' },
    { text: '🏠 Menu Utama', callback_data: 'menu_main' }
  ]);
  return { inline_keyboard: buttons };
}

function buildBuyConfirmKeyboard(productId) {
  return {
    inline_keyboard: [
      [{ text: '✅ Ya, Beli Sekarang!', callback_data: `confirm_buy_${productId}` }],
      [{ text: '❌ Batal', callback_data: `product_${productId}` }]
    ]
  };
}

function buildTopupMethodKeyboard(methods) {
  const buttons = (methods || []).map(method => [{
    text: `💳 ${method}`,
    callback_data: `topup_method_${method}`
  }]);
  buttons.push([{ text: '◀️ Kembali', callback_data: 'menu_main' }]);
  return { inline_keyboard: buttons };
}

function buildTopupConfirmKeyboard(topupId) {
  return {
    inline_keyboard: [
      [{ text: '📸 Kirim Bukti Transfer', callback_data: `topup_sendproof_${topupId}` }],
      [{ text: '❌ Batalkan Topup', callback_data: `topup_cancel_${topupId}` }]
    ]
  };
}

function buildAdminTopupKeyboard(topupId) {
  return {
    inline_keyboard: [[
      { text: '✅ APPROVE', callback_data: `admin_approve_${topupId}` },
      { text: '❌ REJECT', callback_data: `admin_reject_${topupId}` }
    ]]
  };
}

function buildPurchaseListKeyboard(purchases, page = 0, perPage = 5) {
  const start = page * perPage;
  const pagePurchases = purchases.slice(start, start + perPage);
  const totalPages = Math.ceil(purchases.length / perPage);

  const buttons = pagePurchases.map((purchase, idx) => [{
    text: `📦 #${start + idx + 1} ${purchase.productName}`,
    callback_data: `purchase_detail_${purchase.id}`
  }]);

  const navButtons = [];
  if (page > 0) navButtons.push({ text: '◀️ Sebelumnya', callback_data: `purchases_page_${page - 1}` });
  if (page < totalPages - 1) navButtons.push({ text: 'Selanjutnya ▶️', callback_data: `purchases_page_${page + 1}` });
  if (navButtons.length > 0) buttons.push(navButtons);
  buttons.push([{ text: '🏠 Menu Utama', callback_data: 'menu_main' }]);

  return { inline_keyboard: buttons };
}

module.exports = {
  formatCurrency, formatDate, formatDateShort, formatRelativeTime, formatNumber,
  createProgressBar, getLevelBadge, getLevelName, getUserName, getUserMention,
  escHtml, isValidAmount, isAdmin,
  buildWelcomeHTML, buildProfileHTML, buildProductHTML, buildTopupHTML,
  buildAdminTopupHTML, buildPurchaseSuccessHTML, buildPurchaseDetailHTML,
  buildMainKeyboard, buildProductListKeyboard, buildProductDetailKeyboard,
  buildBuyConfirmKeyboard, buildTopupMethodKeyboard, buildTopupConfirmKeyboard,
  buildAdminTopupKeyboard, buildPurchaseListKeyboard
};
