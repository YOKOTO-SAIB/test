/**
 * =====================================================
 * DATABASE MANAGER - JSON FILE BASED STORAGE
 * =====================================================
 * Mengelola semua data menggunakan file JSON
 * Tidak menggunakan SQL database
 * =====================================================
 */

const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');

// ─── PATHS ───────────────────────────────────────────────────────────────────
const DATA_DIR = path.join(__dirname, '../data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');
const TRANSACTIONS_FILE = path.join(DATA_DIR, 'transactions.json');
const TOPUP_FILE = path.join(DATA_DIR, 'topups.json');
const PURCHASES_FILE = path.join(DATA_DIR, 'purchases.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const LOGS_FILE = path.join(DATA_DIR, 'logs.json');

// ─── INIT DATABASE ────────────────────────────────────────────────────────────
async function initDatabase() {
  await fs.ensureDir(DATA_DIR);

  // Init users.json
  if (!await fs.pathExists(USERS_FILE)) {
    await fs.writeJson(USERS_FILE, { users: {} }, { spaces: 2 });
    console.log('✅ users.json created');
  }

  // Init products.json
  if (!await fs.pathExists(PRODUCTS_FILE)) {
    const defaultProducts = {
      products: {
        "prod_001": {
          id: "prod_001",
          name: "Premium Account Netflix",
          description: "Akun Netflix Premium 1 Bulan - Shared Screen\n✅ Garansi Full 30 Hari\n✅ 4K Ultra HD\n✅ Bisa di semua device\n✅ Support 24/7",
          price: 25000,
          stock: 15,
          category: "streaming",
          image: null,
          postPurchaseInfo: "🎉 SELAMAT! Pembelian Berhasil!\n\n📧 Email: netflix@example.com\n🔑 Password: Pass123!\n📌 Profile: Slot 3\n\n⚠️ PENTING:\n- Jangan ganti password\n- Jangan keluarkan dari profil\n- Report jika ada masalah",
          sold: 42,
          active: true,
          createdAt: moment().format(),
          updatedAt: moment().format()
        },
        "prod_002": {
          id: "prod_002",
          name: "Spotify Premium 1 Bulan",
          description: "Spotify Premium Individual\n✅ Tanpa Iklan\n✅ Download Offline\n✅ Kualitas Audio Terbaik\n✅ Garansi 30 Hari",
          price: 18000,
          stock: 20,
          category: "streaming",
          image: null,
          postPurchaseInfo: "🎉 SELAMAT! Pembelian Berhasil!\n\n📧 Email: spotify@example.com\n🔑 Password: Spot456!\n\n⚠️ JANGAN:\n- Ganti email/password\n- Share ke orang lain\n\n✅ Nikmati musik sepuasnya!",
          sold: 67,
          active: true,
          createdAt: moment().format(),
          updatedAt: moment().format()
        },
        "prod_003": {
          id: "prod_003",
          name: "Disney+ Hotstar 1 Bulan",
          description: "Disney+ Hotstar Premium\n✅ Konten Disney, Marvel, Star Wars\n✅ Live Sport\n✅ Full HD\n✅ Garansi 30 Hari",
          price: 20000,
          stock: 10,
          category: "streaming",
          image: null,
          postPurchaseInfo: "🎉 SELAMAT! Pembelian Berhasil!\n\n📧 Email: disney@example.com\n🔑 Password: Dis789!\n\n📌 Catatan:\n- Akses melalui profile ke-2\n- Jangan ubah data akun",
          sold: 31,
          active: true,
          createdAt: moment().format(),
          updatedAt: moment().format()
        },
        "prod_004": {
          id: "prod_004",
          name: "YouTube Premium 1 Bulan",
          description: "YouTube Premium\n✅ Tanpa Iklan\n✅ Background Play\n✅ YouTube Music Included\n✅ Garansi 30 Hari",
          price: 22000,
          stock: 8,
          category: "streaming",
          image: null,
          postPurchaseInfo: "🎉 SELAMAT! Pembelian Berhasil!\n\n📧 Email: youtube@example.com\n🔑 Password: YT321!\n\n✅ Enjoy tanpa iklan!",
          sold: 28,
          active: true,
          createdAt: moment().format(),
          updatedAt: moment().format()
        },
        "prod_005": {
          id: "prod_005",
          name: "VPN Premium 1 Bulan",
          description: "VPN Premium All Server\n✅ Unlimited Bandwidth\n✅ 50+ Server Negara\n✅ No Log Policy\n✅ Garansi 30 Hari",
          price: 15000,
          stock: 25,
          category: "tools",
          image: null,
          postPurchaseInfo: "🎉 SELAMAT! Pembelian Berhasil!\n\n🔑 License Key: VPN-XXXX-XXXX-XXXX\n📥 Download: https://vpn.example.com\n\n✅ Aktivasi sesuai petunjuk di website",
          sold: 89,
          active: true,
          createdAt: moment().format(),
          updatedAt: moment().format()
        }
      }
    };
    await fs.writeJson(PRODUCTS_FILE, defaultProducts, { spaces: 2 });
    console.log('✅ products.json created with default products');
  }

  // Init transactions.json
  if (!await fs.pathExists(TRANSACTIONS_FILE)) {
    await fs.writeJson(TRANSACTIONS_FILE, { transactions: {} }, { spaces: 2 });
    console.log('✅ transactions.json created');
  }

  // Init topups.json
  if (!await fs.pathExists(TOPUP_FILE)) {
    await fs.writeJson(TOPUP_FILE, { topups: {} }, { spaces: 2 });
    console.log('✅ topups.json created');
  }

  // Init purchases.json
  if (!await fs.pathExists(PURCHASES_FILE)) {
    await fs.writeJson(PURCHASES_FILE, { purchases: {} }, { spaces: 2 });
    console.log('✅ purchases.json created');
  }

  // Init settings.json
  if (!await fs.pathExists(SETTINGS_FILE)) {
    const defaultSettings = {
      botName: "🛒 MyStore Bot",
      welcomeText: "Selamat datang di MyStore! Toko terpercaya dengan produk berkualitas premium. 🎉\n\nSilakan pilih menu di bawah ini untuk mulai berbelanja!",
      aboutText: "🤖 Tentang Bot Ini:\n\nNama: MyStore Bot\nVersi: 2.0.0\nDeveloper: @admin\n\n📋 Fitur:\n✅ Toko produk digital\n✅ Sistem topup otomatis\n✅ Verifikasi admin\n✅ Riwayat pembelian\n✅ Multi metode pembayaran\n\n📞 Kontak Admin: @admin\n🌐 Website: coming soon\n\n💡 Bot ini aktif 24/7 untuk melayani Anda!",
      groupLink: "https://t.me/mystore_group",
      channelLink: "https://t.me/mystore_channel",
      adminContact: "@admin",
      qrisImage: null,
      tagImage: null,
      tagAudio: null,
      paymentMethods: ["DANA", "OVO", "GoPay", "BCA"],
      paymentNumbers: {
        "DANA": "08123456789",
        "OVO": "08123456789",
        "GoPay": "08123456789",
        "BCA": "1234567890"
      },
      paymentOwner: "John Doe",
      minTopup: 10000,
      maxTopup: 10000000,
      maintenanceMode: false,
      maintenanceMessage: "Bot sedang dalam maintenance. Coba lagi nanti.",
      levels: {
        "1": { name: "Newcomer", minExp: 0, maxExp: 100, badge: "🌱" },
        "2": { name: "Member", minExp: 100, maxExp: 500, badge: "⭐" },
        "3": { name: "Regular", minExp: 500, maxExp: 1500, badge: "💫" },
        "4": { name: "VIP", minExp: 1500, maxExp: 5000, badge: "👑" },
        "5": { name: "Legend", minExp: 5000, maxExp: 999999, badge: "🏆" }
      },
      updatedAt: moment().format()
    };
    await fs.writeJson(SETTINGS_FILE, defaultSettings, { spaces: 2 });
    console.log('✅ settings.json created');
  }

  // Init logs.json
  if (!await fs.pathExists(LOGS_FILE)) {
    await fs.writeJson(LOGS_FILE, { logs: [] }, { spaces: 2 });
    console.log('✅ logs.json created');
  }

  console.log('🗄️  Database initialized successfully!');
}

// ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────
async function readJson(filePath) {
  try {
    return await fs.readJson(filePath);
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
    return null;
  }
}

async function writeJson(filePath, data) {
  try {
    await fs.writeJson(filePath, data, { spaces: 2 });
    return true;
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
    return false;
  }
}

// ─── LOG SYSTEM ───────────────────────────────────────────────────────────────
async function addLog(type, message, data = {}) {
  const logsData = await readJson(LOGS_FILE);
  if (!logsData) return;

  const logEntry = {
    id: uuidv4(),
    type,
    message,
    data,
    timestamp: moment().format()
  };

  logsData.logs.unshift(logEntry);
  
  // Keep only last 1000 logs
  if (logsData.logs.length > 1000) {
    logsData.logs = logsData.logs.slice(0, 1000);
  }

  await writeJson(LOGS_FILE, logsData);
}

// ─── USER FUNCTIONS ───────────────────────────────────────────────────────────
async function getUser(userId) {
  const data = await readJson(USERS_FILE);
  return data?.users?.[userId] || null;
}

async function createUser(telegramUser) {
  const data = await readJson(USERS_FILE);
  if (!data) return null;

  const userId = telegramUser.id.toString();
  
  if (data.users[userId]) {
    // Update last seen
    data.users[userId].lastSeen = moment().format();
    data.users[userId].username = telegramUser.username || data.users[userId].username;
    data.users[userId].firstName = telegramUser.first_name || data.users[userId].firstName;
    data.users[userId].lastName = telegramUser.last_name || data.users[userId].lastName;
    await writeJson(USERS_FILE, data);
    return data.users[userId];
  }

  const newUser = {
    id: userId,
    telegramId: telegramUser.id,
    username: telegramUser.username || null,
    firstName: telegramUser.first_name || 'User',
    lastName: telegramUser.last_name || '',
    balance: 0,
    exp: 0,
    level: 1,
    totalTopup: 0,
    totalSpent: 0,
    purchaseCount: 0,
    isBlocked: false,
    isBanned: false,
    banReason: null,
    joinedAt: moment().format(),
    lastSeen: moment().format(),
    purchases: [],
    pendingTopup: null,
    notes: ""
  };

  data.users[userId] = newUser;
  await writeJson(USERS_FILE, data);
  await addLog('USER_JOIN', `New user joined: ${newUser.firstName}`, { userId });
  return newUser;
}

async function updateUser(userId, updates) {
  const data = await readJson(USERS_FILE);
  if (!data || !data.users[userId]) return null;

  data.users[userId] = {
    ...data.users[userId],
    ...updates,
    updatedAt: moment().format()
  };

  await writeJson(USERS_FILE, data);
  return data.users[userId];
}

async function getAllUsers() {
  const data = await readJson(USERS_FILE);
  return Object.values(data?.users || {});
}

async function addUserExp(userId, exp) {
  const user = await getUser(userId);
  if (!user) return null;

  const settings = await getSettings();
  const newExp = user.exp + exp;
  let newLevel = user.level;

  // Calculate new level
  Object.entries(settings.levels).forEach(([level, config]) => {
    if (newExp >= config.minExp) {
      newLevel = parseInt(level);
    }
  });

  return await updateUser(userId, { exp: newExp, level: newLevel });
}

async function getUserLevel(user) {
  const settings = await getSettings();
  const levelConfig = settings.levels[user.level.toString()];
  return levelConfig || settings.levels["1"];
}

// ─── PRODUCT FUNCTIONS ────────────────────────────────────────────────────────
async function getProduct(productId) {
  const data = await readJson(PRODUCTS_FILE);
  return data?.products?.[productId] || null;
}

async function getAllProducts(activeOnly = true) {
  const data = await readJson(PRODUCTS_FILE);
  const products = Object.values(data?.products || {});
  return activeOnly ? products.filter(p => p.active) : products;
}

async function createProduct(productData) {
  const data = await readJson(PRODUCTS_FILE);
  if (!data) return null;

  const productId = 'prod_' + uuidv4().split('-')[0];
  const newProduct = {
    id: productId,
    name: productData.name,
    description: productData.description || '',
    price: parseInt(productData.price) || 0,
    stock: parseInt(productData.stock) || 0,
    category: productData.category || 'general',
    image: productData.image || null,
    postPurchaseInfo: productData.postPurchaseInfo || 'Terima kasih telah berbelanja!',
    sold: 0,
    active: true,
    createdAt: moment().format(),
    updatedAt: moment().format()
  };

  data.products[productId] = newProduct;
  await writeJson(PRODUCTS_FILE, data);
  await addLog('PRODUCT_CREATE', `Product created: ${newProduct.name}`, { productId });
  return newProduct;
}

async function updateProduct(productId, updates) {
  const data = await readJson(PRODUCTS_FILE);
  if (!data || !data.products[productId]) return null;

  data.products[productId] = {
    ...data.products[productId],
    ...updates,
    updatedAt: moment().format()
  };

  await writeJson(PRODUCTS_FILE, data);
  return data.products[productId];
}

async function deleteProduct(productId) {
  const data = await readJson(PRODUCTS_FILE);
  if (!data || !data.products[productId]) return false;

  const productName = data.products[productId].name;
  delete data.products[productId];
  await writeJson(PRODUCTS_FILE, data);
  await addLog('PRODUCT_DELETE', `Product deleted: ${productName}`, { productId });
  return true;
}

async function decreaseProductStock(productId) {
  const data = await readJson(PRODUCTS_FILE);
  if (!data || !data.products[productId]) return false;

  if (data.products[productId].stock <= 0) return false;

  data.products[productId].stock--;
  data.products[productId].sold++;
  data.products[productId].updatedAt = moment().format();
  await writeJson(PRODUCTS_FILE, data);
  return true;
}

// ─── PURCHASE FUNCTIONS ───────────────────────────────────────────────────────
async function createPurchase(userId, productId) {
  const user = await getUser(userId);
  const product = await getProduct(productId);

  if (!user || !product) return { success: false, error: 'User atau produk tidak ditemukan' };
  if (user.balance < product.price) return { success: false, error: 'Saldo tidak mencukupi' };
  if (product.stock <= 0) return { success: false, error: 'Stok habis' };

  // Deduct balance
  await updateUser(userId, {
    balance: user.balance - product.price,
    totalSpent: user.totalSpent + product.price,
    purchaseCount: user.purchaseCount + 1
  });

  // Decrease stock
  await decreaseProductStock(productId);

  // Create purchase record
  const purchasesData = await readJson(PURCHASES_FILE);
  const purchaseId = 'buy_' + uuidv4().split('-')[0];
  
  const purchase = {
    id: purchaseId,
    userId,
    productId,
    productName: product.name,
    price: product.price,
    postPurchaseInfo: product.postPurchaseInfo,
    status: 'completed',
    purchasedAt: moment().format()
  };

  if (!purchasesData.purchases[userId]) {
    purchasesData.purchases[userId] = [];
  }
  purchasesData.purchases[userId].unshift(purchase);
  await writeJson(PURCHASES_FILE, purchasesData);

  // Add exp
  const expGained = Math.floor(product.price / 1000) + 5;
  await addUserExp(userId, expGained);

  await addLog('PURCHASE', `User ${userId} bought ${product.name} for Rp${product.price.toLocaleString('id-ID')}`, { purchaseId, userId, productId });

  return { success: true, purchase, product, expGained };
}

async function getUserPurchases(userId) {
  const data = await readJson(PURCHASES_FILE);
  return data?.purchases?.[userId] || [];
}

// ─── TOPUP FUNCTIONS ──────────────────────────────────────────────────────────
async function createTopup(userId, amount, method, paymentNumber) {
  const data = await readJson(TOPUP_FILE);
  if (!data) return null;

  const topupId = 'top_' + uuidv4().split('-')[0];
  const topup = {
    id: topupId,
    userId,
    amount: parseInt(amount),
    method,
    paymentNumber,
    status: 'pending',
    proofImage: null,
    adminNote: null,
    processedBy: null,
    createdAt: moment().format(),
    updatedAt: moment().format()
  };

  data.topups[topupId] = topup;
  await writeJson(TOPUP_FILE, data);

  // Set pending topup to user
  await updateUser(userId, { pendingTopup: topupId });
  await addLog('TOPUP_CREATE', `Topup created: ${userId} - Rp${amount.toLocaleString('id-ID')}`, { topupId, userId, amount });
  
  return topup;
}

async function getTopup(topupId) {
  const data = await readJson(TOPUP_FILE);
  return data?.topups?.[topupId] || null;
}

async function updateTopup(topupId, updates) {
  const data = await readJson(TOPUP_FILE);
  if (!data || !data.topups[topupId]) return null;

  data.topups[topupId] = {
    ...data.topups[topupId],
    ...updates,
    updatedAt: moment().format()
  };

  await writeJson(TOPUP_FILE, data);
  return data.topups[topupId];
}

async function getAllTopups() {
  const data = await readJson(TOPUP_FILE);
  return Object.values(data?.topups || {}).sort((a, b) => 
    new Date(b.createdAt) - new Date(a.createdAt)
  );
}

async function getPendingTopups() {
  const topups = await getAllTopups();
  return topups.filter(t => t.status === 'pending' && t.proofImage);
}

async function approveTopup(topupId, adminId) {
  const topup = await getTopup(topupId);
  if (!topup || topup.status !== 'pending') return { success: false, error: 'Topup tidak valid' };

  // Update topup status
  await updateTopup(topupId, {
    status: 'approved',
    processedBy: adminId,
    processedAt: moment().format()
  });

  // Add balance to user
  const user = await getUser(topup.userId);
  if (!user) return { success: false, error: 'User tidak ditemukan' };

  await updateUser(topup.userId, {
    balance: user.balance + topup.amount,
    totalTopup: user.totalTopup + topup.amount,
    pendingTopup: null
  });

  // Add exp
  const expGained = Math.floor(topup.amount / 5000) + 10;
  await addUserExp(topup.userId, expGained);

  await addLog('TOPUP_APPROVE', `Topup approved: ${topup.userId} +Rp${topup.amount.toLocaleString('id-ID')}`, { topupId, adminId });

  return { success: true, topup, user };
}

async function rejectTopup(topupId, adminId, reason = 'Bukti tidak valid') {
  const topup = await getTopup(topupId);
  if (!topup || topup.status !== 'pending') return { success: false, error: 'Topup tidak valid' };

  await updateTopup(topupId, {
    status: 'rejected',
    processedBy: adminId,
    adminNote: reason,
    processedAt: moment().format()
  });

  // Clear pending topup from user
  await updateUser(topup.userId, { pendingTopup: null });

  await addLog('TOPUP_REJECT', `Topup rejected: ${topup.userId}`, { topupId, adminId, reason });

  return { success: true, topup };
}

// ─── SETTINGS FUNCTIONS ───────────────────────────────────────────────────────
async function getSettings() {
  const data = await readJson(SETTINGS_FILE);
  return data || {};
}

async function updateSettings(updates) {
  const settings = await getSettings();
  const newSettings = {
    ...settings,
    ...updates,
    updatedAt: moment().format()
  };
  await writeJson(SETTINGS_FILE, newSettings);
  return newSettings;
}

// ─── STATS FUNCTIONS ──────────────────────────────────────────────────────────
async function getStats() {
  const users = await getAllUsers();
  const products = await getAllProducts(false);
  const topups = await getAllTopups();
  const purchases = await readJson(PURCHASES_FILE);

  const totalPurchases = Object.values(purchases?.purchases || {})
    .reduce((sum, userPurchases) => sum + userPurchases.length, 0);

  const totalRevenue = topups
    .filter(t => t.status === 'approved')
    .reduce((sum, t) => sum + t.amount, 0);

  const pendingTopups = topups.filter(t => t.status === 'pending' && t.proofImage).length;

  return {
    totalUsers: users.length,
    activeUsers: users.filter(u => !u.isBanned).length,
    totalProducts: products.length,
    activeProducts: products.filter(p => p.active).length,
    totalPurchases,
    totalRevenue,
    pendingTopups,
    lowStockProducts: products.filter(p => p.stock <= 5 && p.active).length
  };
}

async function getLogs(limit = 100) {
  const data = await readJson(LOGS_FILE);
  return (data?.logs || []).slice(0, limit);
}

// ─── EXPORT ───────────────────────────────────────────────────────────────────
module.exports = {
  initDatabase,
  addLog,
  // Users
  getUser,
  createUser,
  updateUser,
  getAllUsers,
  addUserExp,
  getUserLevel,
  // Products
  getProduct,
  getAllProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  decreaseProductStock,
  // Purchases
  createPurchase,
  getUserPurchases,
  // Topups
  createTopup,
  getTopup,
  updateTopup,
  getAllTopups,
  getPendingTopups,
  approveTopup,
  rejectTopup,
  // Settings
  getSettings,
  updateSettings,
  // Stats
  getStats,
  getLogs
};
